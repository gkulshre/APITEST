/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import RMQBase from './rmq_base';

export default class OrchSyncResponder extends RMQBase {
  constructor() {
    super(process.env.RABBITMQ_ORCH_SYNC_RESP_QUEUE, process.env.RABBITMQ_ORCH_SYNC_RESP_ROUTE, 'Orchestration Sync Responder');
    this.handle_message = this.handle_message.bind(this);
  }

  handle_message(msg){
    let qres = {};
    logger.debug(`Orch Sync Response returned from route: '${msg.fields.routingKey}' with ID of: 
    '${msg.properties.correlationId}'`);
    try {
      if (orchSyncQueue.has(msg.properties.correlationId)){
        qres = orchSyncQueue.get(msg.properties.correlationId);
        orchSyncQueue.delete(msg.properties.correlationId);

        let result = JSON.parse(msg.content.toString());
        try {
          if (result.result){
            qres.cb(result, qres.req, qres.res, qres.last_route, qres.opts);
          } else {
            logger.debug(`Orch Sync Response returned from route: '${msg.fields.routingKey}' with ID of: 
            '${msg.properties.correlationId}' had error '${result.error}'`);
            logger.debug(result.error);
            logger.debug(JSON.stringify(result.error));
            this.send_error(qres.res, result.error, 500, result.type, result.code);
          }
        } catch (err) {
          logger.debug(`!!!!!!Orch Sync Response returned from route: '${msg.fields.routingKey}' with ID of: 
          '${msg.properties.correlationId}' is not in API FORMAT`);
          logger.error(err.message);
          this.send_error(qres.res, err.message, 500, null, null);
        }

      } else {
        logger.warn(`Received unexpected message on:  '${msg.fields.routingKey}' with ID of: 
        '${msg.properties.correlationId}'`);
      }
    } catch (err){
      logger.error(err.message);
      if (orchSyncQueue.has(msg.properties.correlationId)){
        qres = orchSyncQueue.get(msg.properties.correlationId);
        orchSyncQueue.delete(msg.properties.correlationId);
        this.send_error(qres.res, err.message, 500, null, null);
      }
    }
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import RMQBase from './rmq_base';

export default class LoggingListener extends RMQBase {
  constructor() {
    super(process.env.RABBITMQ_LOG_QUEUE, process.env.RABBITMQ_LOG_ROUTE, 'Logging Listener');
  }

  handle_message(msg){
    try {
      let result = JSON.parse(msg.content.toString());
      let routingKey = msg.fields.routingKey.split('.');

      let objKey = {};
      objKey.node_id = routingKey[0];
      objKey.component_name = routingKey[1];
      objKey.service_type = routingKey[2];
      objKey.instance_id = routingKey[3];
      objKey.command = routingKey[4];
      objKey.source_object = routingKey[5];
      objKey.event_time = result.time;
      objKey.log_level = result.level;
      objKey.message = result.message;
      objKey.thread = result.thread ? result.thread : undefined;
      objKey.stack_trace = result.stacktrace ? result.stacktrace : undefined;
      objKey.error_type = result.type ? result.type : undefined;
      objKey.error_message = result.error_message ? result.error_message : undefined;
      if (process.env.SERVER_LOG_VERBOSE) {
        logger.debug(`Sending log socket comp:${objKey.component_name} message: ${objKey.message}`);
      } else {
        logger.debug(`Sending log socket comp:${objKey.component_name} message: ${objKey.message.substr(0, process.env.SERVER_LOGGING_DEBUG_MESSAGE_MAX_LENGTH)}`);
      }
      io.sendLogMessage(JSON.stringify(objKey));
    } catch (err){
      logger.error(`Error parsing Log Message:  '${err.message}'`);
    }
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import amqp from 'amqplib';
import SyncResponder from './sync_responder';
import OrchSyncResonder from './orch_sync_responder';
import OrchAsyncEventListener from './orch_async_event_listener';
import Publisher from './publisher';
import LoggingListener from './logging_listener';
import MatrixDomainResponder from './matrix_domain_responder';
import MatrixRoleResponder from './matrix_role_responder';
import AttackEventListener from './attack_event_listener';
import StructuredEventListener from './structured_event_listener';

const rmqCont = (cb) => {
  const rmqConn = {};
  rmqConn.max_retry = process.env.RABBITMQ_RETRY_ATTEMPTS;
  rmqConn.retry_interval = process.env.RABBITMQ_RETRY_INTERVAL;
  rmqConn.cnt = 0;
  rmqConn.monitorState = false;
  rmqConn.host = {
    protocol: 'amqp',
    hostname: process.env.RABBITMQ_HOST,
    port: process.env.RABBITMQ_PORT,
    username: process.env.RABBITMQ_USERNAME,
    password: process.env.RABBITMQ_PASSWORD,
    locale: 'en_US',
    heartbeat: process.env.RABBITMQ_HEARTBEAT,
    vhost: '/'};

  rmqConn.connected = false;
  rmqConn.terminated = false;
  rmqConn.connection = null;
  rmqConn.channel = null;
  rmqConn.interval = null;
  rmqConn.channelClosed = true;


  rmqConn.SYR = new SyncResponder();
  rmqConn.OSR = new OrchSyncResonder();
  rmqConn.OAEL = new OrchAsyncEventListener();
  rmqConn.PUB = new Publisher(rmqConn);
  rmqConn.LOG = new LoggingListener();
  rmqConn.MDR = new MatrixDomainResponder();
  rmqConn.MRR = new MatrixRoleResponder();
  rmqConn.AEL = new AttackEventListener();
  rmqConn.SEL = new StructuredEventListener();

  rmqConn.start = () => {
    logger.debug('In RMQ Start...');
    if (!rmqConn.connection) {
      if (rmqConn.interval != null) { clearInterval(rmqConn.interval); }
      logger.debug('Attempting to connect to RMQ...');
      try {
        amqp.connect(rmqConn.host)
          .then((result) => {
            logger.debug('Attempting to create channel');
            rmqConn.connection = result;
            rmqConn.connection.createChannel()
              .then((cresult) => {
                rmqConn.channel = cresult;
                logger.debug('Creating RMQ Exchange....');
                rmqConn.channel.assertExchange(process.env.RABBITMQ_EXCH, 'topic', {durable: true});
                rmqConn.connected = true;
                rmqConn.lastStart = Date.now();
                rmqConn.channelClosed = false;
                rmqConn.cnt = 0;
                rmqConn.channel.on('error', rmqConn.handleConnErrror);
                rmqConn.channel.on('close', rmqConn.handleConnClose);
                logger.info('RabbitMQ Connected');
                rmqConn.monitorState = false;

                rmqConn.SYR.start(rmqConn.channel);
                rmqConn.OSR.start(rmqConn.channel);
                rmqConn.OAEL.start(rmqConn.channel);
                rmqConn.LOG.start(rmqConn.channel);
                rmqConn.MDR.start(rmqConn.channel);
                rmqConn.MRR.start(rmqConn.channel);
                rmqConn.AEL.start(rmqConn.channel);
                rmqConn.SEL.start(rmqConn.channel);

                if (!rmqConn.monitorState) { rmqConn.asyncMonitor(); }

                return null;
              })
              .catch((err) => {
                logger.error('Unable to create channel Error:  ' + err.message);
                throw (err);
              });
            process.once('SIGINT', () => {
              rmqConn.terminated = true;
              rmqConn.connection.close.bind(rmqConn.connection);
            });
            return null;
          })
          .catch((err) => {
            rmqConn.cnt++;
            logger.error('RMQ Connection Error:  ' + err.message);
            if (rmqConn.cnt >= rmqConn.max_retry) {
              logger.error('RabbitMQ retry attempts exceeded');
              rmqConn.connected = false;
              rmqConn.connection = null;
              cb('Failed to connect to RabbitMQ');
              return;
            }
            return setTimeout(rmqConn.start, rmqConn.retry_interval);
          });
      } catch (err) {
        logger.error(`Error trying to connect to RMA:  ${err.message}`);
      }

    }
  };

  const sleep = (milliseconds) => {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  };

  rmqConn.blockingStart = async(cb) => {
    rmqConn.start();
    while (!rmqConn.connected){
      await sleep(100).then(() => {
        if (rmqConn.connected){
          cb();
        }
      });
    }
  };

  rmqConn.close = () => {
    rmqConn.terminated = true;
    if (rmqConn.connected && rmqConn.connection != null){
      rmqConn.connection.close.bind(rmqConn.connection);
    }
  };

  rmqConn.asyncMonitor = () => {
    rmqConn.interval = setInterval(rmqConn.monitor, rmqConn.retry_interval);
  };

  rmqConn.monitor = () => { // No mutex control so slight chance it will try to restart during restart
    if (!rmqConn.terminated){
      rmqConn.monitorState = true;
      if (rmqConn.channelClosed && !rmqConn.terminated){
        logger.info('Trying to restart RabbitMQ Connection');
        try {
          rmqConn.connection.close.bind(rmqConn.connection);
        } catch (err) {
          logger.error(err.message);
        } finally {
          rmqConn.connection = null;
        }

        rmqConn.start();
      }
    }
  };

  rmqConn.handleConnErrror = (error) => {
    logger.error('RabbitMQ channel error:  ' + error);
    rmqConn.channelClosed = true;
  };

  rmqConn.handleConnClose = (message) => {
    if (!rmqConn.terminated) {
      logger.error('Channel closed unexpectantly:  ' + message);
    }
    rmqConn.channelClosed = true;
  };

  return rmqConn;
};

module.exports = rmqCont;

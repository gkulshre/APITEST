/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import Formatting from '../util/formatting';

export default class RMQBase {
  constructor(queue, route, ltype) {
    this.queue = queue;
    this.route = route;
    this.type = ltype;
  }

  start(channel) {
    try {
      let que = {};
      channel.assertQueue(this.queue, {exclusive: false}, function(err, q) {
        if (err){
          logger.error(`Error setting up ${this.type} queue: ${err.message}`);
          throw err;
        } else {
          que = q;
        }
        que = q;
      });
      if (this.route){
        channel.bindQueue(que.queue, process.env.RABBITMQ_EXCH, this.route);
        channel.bindQueue(que.queue, process.env.RABBITMQ_EXCH);
      } else {
        channel.bindQueue(que.queue, process.env.RABBITMQ_EXCH); //, this.route);
      }
      return channel.consume(que.queue, this.handle_message, {noAck: true});
    } catch (err) {
      logger.error(`Error setting up ${this.type}: ${err.message}`);
      return null;
    }
  }

  handle_message(msg) {
    throw new Error("Function 'handle_message' undefined");
  }

  send_error(res, message, status = 500, type = 'Internal Server Error', code = null){
    try {
      logger.error(`Error Caught:: ${message}`);
      if (res.headersSent === false){
        var formattedMsg = Formatting.formatError(code, type, message);
        logger.debug(JSON.stringify(formattedMsg, null, 2));
        res.status(status).send(Formatting.formatError(code, type, message));
      }
    } catch (err) {
      logger.error(`Unable to send error message:: ${err.message}`);
    }
  }
}

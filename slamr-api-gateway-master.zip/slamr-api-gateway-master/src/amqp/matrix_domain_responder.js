/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import RMQBase from './rmq_base';

export default class MatrixDomainResponder extends RMQBase {
  constructor() {
    super(process.env.RABBITMQ_MATRIX_RESP_QUEUE, process.env.RABBITMQ_MATRIX_RESP_ROUTE, 'Matrix Responder');
  }

  handle_message(msg){
    try {
      switch (msg.fields.routingKey) {
        case process.env.RABBITMQ_MATRIX_RESP_ROUTE:
          security.matrix.dm.parseResult(msg.content.toString());
          break;
      }

    } catch (err){
      logger.error('Error handling message: ' + err.message);
    }
  }
}

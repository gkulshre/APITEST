/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import RMQBase from './rmq_base';

export default class SyncResponder extends RMQBase {
  constructor() {
    super(process.env.RABBITMQ_SYNC_RESP_QUEUE, process.env.RABBITMQ_SYNC_RESP_ROUTE, 'Sync Responder');
    this.handle_message = this.handle_message.bind(this);
  }

  handle_message(msg){
    let res = {};
    try {
      if (syncQueue.has(msg.properties.correlationId)){
        res = syncQueue.get(msg.properties.correlationId);
        syncQueue.delete(msg.properties.correlationId);

        let message = 'Oops.  Something went wrong';
        let result_status = 100;
        let result = JSON.parse(msg.content.toString());
        let result_type = 'success';
        let error_code;
        try {
          if (result.result){
            result_status = 200;
            message = result.data;
            res.status(result_status).send(message);
            logger.debug(`Response returned from route: '${msg.fields.routingKey}' with ID of: 
            '${msg.properties.correlationId}'`);
            if (process.env.SERVER_LOG_VERBOSE) {
              logger.debug(`Sync Payload: '${JSON.stringify(message)}`);
            }
          } else {
            logger.debug(`Response returned from route: '${msg.fields.routingKey}' with ID of: 
            '${msg.properties.correlationId}' had error`);
            logger.debug(JSON.stringify(result.error, null, 2));
            result_status = 500;
            result_type = 'error';
            if (result.error) {
              error_code = result.error.code;
              if (result.error.code && result.error.code >= 300 && result.error.code <= 599) {
                result_status = result.error.code;
              }
            }
            if (result.error && result.error.msg) {
              message = result.error.msg;
            }
            if (result.type) {
              result_type = result.type;
            }
            this.send_error(res, message, result_status, result_type, error_code);
          }
        } catch (err) {
          console.log(msg);
          logger.debug(`!!!!!!Response returned from route: '${msg.fields.routingKey}' with ID of: 
          '${msg.properties.correlationId}' is not in API FORMAT`);
          logger.error(err.message);
          logger.error(msg);
          this.send_error(res, result.error, 500, result.type, result.code);
        }

      } else {
        console.log('WTH');
        logger.warn(`Received unexpected message on:  '${msg.fields.routingKey}' with ID of: 
        '${msg.properties.correlationId}'`);
      }
    } catch (err){
      logger.error(err.message);
      if (syncQueue.has(msg.properties.correlationId)){
        syncQueue.delete(msg.properties.correlationId);
      }
      this.send_error(res, err.message, 500, null, null);
    }
  }
}

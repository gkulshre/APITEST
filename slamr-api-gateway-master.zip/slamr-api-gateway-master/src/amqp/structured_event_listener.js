/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import RMQBase from './rmq_base';

export default class StructuredEventListener extends RMQBase {
  constructor() {
    super(process.env.RABBITMQ_STRUCTURED_EVENT_QUEUE, process.env.RABBITMQ_STRUCTURED_EVENT_ROUTE, 'Structured Event Listener');
    this.handle_message = this.handle_message.bind(this);
  }

  handle_message(msg){
    logger.debug(`Structured Event received from route: '${msg.fields.routingKey}' with ID of: 
    '${msg.properties.correlationId}'`);
    try {
      let result = JSON.parse(msg.content.toString());
      try {
        if (result.event){
          switch (result.event) {
            case 'DomainCreate':
              this.doDomainCreate(result);
              break;
            case 'DomainDelete':
              this.doDomainDelete(result);
              break;
            case 'DomainDelete_pdw':
              this.doDomainDeletePDW(result);
              break;
            default:
              logger.debug(`Structured Event received from route: '${msg.fields.routingKey}' with ID of: 
            '${msg.properties.correlationId}' had unknown event: '${result}'`);
          }
        } else {
          logger.warn(`Structured Event received from route: '${msg.fields.routingKey}' with ID of: 
            '${msg.properties.correlationId}' could not be parsed: '${result}'`);
        }
      } catch (err) {
        logger.error(`Structured Event Error: '${err.message}'`);
      }
    } catch (err){
      logger.error(`Structured Event Error: '${err.message}'`);
    }
  }

  doDomainCreate(result){
    try {
      logger.debug(`Handling Structured Event Domain Create: '${JSON.stringify(result)}'`);
      security.matrix.start(null);
      let data = { domain_id: result.domain_id, event: result.event, token: result.token };
      io.sendUserMessage(result.sub, data);
    } catch (err) {
      logger.error(`Error with Structured Event Domain Create: '${err.message}'`);
    }
  }

  doDomainDelete(result){
    try {
      logger.debug(`Handling Structured Event Domain Delete: '${JSON.stringify(result)}'`);
      security.matrix.start(null);
      let data = { domain_id: result.domain_id, event: result.event, token: result.token };
      io.sendUserMessage(result.sub, data);
    } catch (err) {
      logger.error(`Error with Structured Event Domain Delete: '${err.message}'`);
    }
  }

  doDomainDeletePDW(result){
    try {
      logger.debug(`Handling Structured Event Delete PDW Domain MG: '${JSON.stringify(result)}'`);
      security.matrix.start(null);
      let data = { domain_id: result.domain_id, event: result.event, token: result.token };
      io.sendUserMessage(result.sub, data);
    } catch (err) {
      logger.error(`Error with Structured Event Domain Delete: '${err.message}'`);
    }
  }
}

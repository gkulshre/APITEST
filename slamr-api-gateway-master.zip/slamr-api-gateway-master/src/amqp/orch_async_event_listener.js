/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import RMQBase from './rmq_base';
import Utils, {SourceTypes} from '../util/utils';

export default class OrchAsyncEventListener extends RMQBase {
  constructor() {
    super(process.env.RABBITMQ_ASYNC_EVENT_LISTENER_QUEUE, process.env.RABBITMQ_ASYNC_EVENT_LISTENER_ROUTE,
      'Orchestration Async Event Listener');
    this.handle_message = this.handle_message.bind(this);
  }
  handle_message(msg) {
    logger.debug(`Orch Async Response returned from route: '${msg.fields.routingKey}' with ID of: 
    '${msg.properties.correlationId}'`);
    try {
      let isError = false;
      let msgSource = Utils.getSourceFromKey(msg.fields.routingKey);
      let result = JSON.parse(msg.content.toString());
      logger.debug(msg.content.toString());
      // Lets try to get an ID

      logger.debug('Parsing Message');
      logger.debug(`Capturing reference ID: ${result.metadata.id}`);
      logger.debug(`Extracting reference ID and Domain ID: ${result.metadata.id} :: ${result.metadata.domain_id}`);
      let tmpID = result.metadata.id;
      let tmpDomainID = result.metadata.domain_id;
      let tmpPayload = {};
      if (result.result === true){
        logger.debug('Processing Success Message');
        let data = {};
        data['data'] = result.data;
        data['metadata'] = result.metadata;
        tmpPayload['data'] = data;
        isError = false;
      } else if (result.result === false) {
        logger.debug('Processing Error Message');
        let error = {};
        error['error'] = result.error;
        error['metadata'] = result.metadata;
        tmpPayload['error'] = error;
        isError = true;
      } else { // there is no result value in the payload???
        logger.debug('Processing Unknown Message');
        logger.debug(`Handling Message ${JSON.stringify(tmpPayload)}`);
        this.processRaw(tmpPayload, msgSource);
      }

      if (isError){
        this.processErrorMsg(tmpPayload, msg.fields.routingKey, msgSource, tmpID, tmpDomainID);
      } else {
        if (tmpID) {
          if (asyncQueue.has(tmpID)) {
            let qres = asyncQueue.get(tmpID);
            asyncQueue.delete(tmpID);
            this.processOrchestration(tmpPayload, qres, msgSource, tmpID, tmpDomainID);
          } else {
            this.processNoOrchestration(tmpPayload, msgSource, tmpID, tmpDomainID);
          }
        } else {
          this.processNoID(tmpPayload, msgSource, tmpDomainID);
        }
      }
    } catch (err){
      logger.error(err.message);
    }
  }

  sendSocketMessage(message, source, domainID){
    switch (source) {
      case SourceTypes.DEVICE:
        logger.debug(`Sending Device Message ${JSON.stringify(message)}`);
        io.sendDeviceMessage(domainID, message);
        break;
      case SourceTypes.CIF:
        logger.debug(`Sending CIF Message ${JSON.stringify(message)}`);
        // io.sendCIFMessage(domainID, message);
        io.sendGlobalCIFMessage(message);
        break;
      case SourceTypes.NETWORK:
        logger.debug(`Sending Network Message ${JSON.stringify(message)}`);
        io.sendNetworkMessage(domainID, message);
        break;
      case SourceTypes.ATTACK:
        logger.debug(`Sending Attack Message ${JSON.stringify(message)}`);
        io.sendAttackMessage(domainID, message);
        break;
      case SourceTypes.TRAFFIC:
        logger.debug(`Sending Traffic Message ${JSON.stringify(message)}`);
        io.sendTrafficMessage(domainID, message);
        break;
      case SourceTypes.DOMAIN:
        security.matrix.start(null);
        logger.debug(`Sending Domain Message ${JSON.stringify(message)}`);
        io.sendDomainMessage(domainID, message);
        break;
      case SourceTypes.INFRASTRUCTURE:
        logger.debug(`Sending Infrastructure Message ${JSON.stringify(message)}`);
        io.sendInfrastructureMessage(message);
        break;
      case SourceTypes.PROJECT:
        logger.debug(`Sending Project Message ${JSON.stringify(message)}`);
        io.sendGlobalProjectMessage(message);
        break;
      case SourceTypes.ERROR:
        logger.debug(`Sending Error Message ${JSON.stringify(message)}`);
        io.sendErrorMessage(message);
        break;
      default:
        logger.warn('Unknown Source.  Cannot send socket message');
    }
  }

  processNoID(message, source, domainID){
    logger.warn(`Async message without ID received from source: '${source}'`);
    if (source === SourceTypes.INFRASTRUCTURE)
      this.sendSocketMessage(message.data, source, null);
    else if (domainID){
      this.sendSocketMessage(message.data, source, domainID);
    } else {
      this.sendSocketMessage(message.data, SourceTypes.ERROR, null);
    }
  }

  processNoOrchestration(message, source, id, domainID){
    logger.debug(`Async message received from source: '${source}' with ID of: '${id}'`);
    if (source === SourceTypes.INFRASTRUCTURE)
      this.sendSocketMessage(message.data, source, null);
    else if (source === SourceTypes.CIF) {
      this.sendSocketMessage(message.data, source, domainID);
    } else if (source === SourceTypes.PROJECT) {
      this.sendSocketMessage(message.data, source, domainID);
    } else if (domainID) {
      this.sendSocketMessage(message.data, source, domainID);
    } else {
      this.sendSocketMessage(message.data, SourceTypes.ERROR, null);
    }
  }

  processOrchestration(message, qitem, source, id){
    logger.debug(`Async Orchestration response received from source: '${source}' with ID of: '${id}'`);
    qitem(message.data, qitem);
  }

  processErrorMsg(message, route, source, id, domainID){
    if (source === SourceTypes.INFRASTRUCTURE)
      this.sendSocketMessage(message.data, source, null);
    else if (id && domainID){
      logger.debug(`Async Orchestration error message received from source: '${source}' on route: '${route}'`);
      this.sendSocketMessage(message.error, SourceTypes.ERROR, domainID);
    } else {
      logger.warn(`Async Orchestration error message received from source: '${source}' on route: '${route}' 
      without ID and DomainID`);
      if (domainID){
        this.sendSocketMessage(message.error, SourceTypes.ERROR, domainID);
      } else {
        this.sendSocketMessage(message.error, SourceTypes.ERROR, null);
      }
    }
  }

  processRaw(message, source, route, domainID){
    logger.warn(`Async Orchestration message unknown format received from source: '${source}' on route: '${route}'`);
    if (source === SourceTypes.INFRASTRUCTURE)
      this.sendSocketMessage(message, source, null);
    else if (domainID){
      this.sendSocketMessage(message, source, domainID);
    } else {
      this.sendSocketMessage(message, SourceTypes.ERROR, null);
    }
  }
}

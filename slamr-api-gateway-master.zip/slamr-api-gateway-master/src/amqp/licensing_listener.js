/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import RMQBase from './rmq_base';

export default class LicenseListener extends RMQBase {
  constructor() {
    super(process.env.RABBITMQ_LICENSE_LISTENER_QUEUE, process.env.RABBITMQ_LICENSE_LISTENER_ROUTE, 'License Listener');
  }

  handle_message(msg){
    try {
      logger.debug('received message on ' + msg.fields.routingKey);
      switch (msg.fields.routingKey) {
        case process.env.RABBITMQ_LICENSE_LISTENER_QUEUE:
          security.license.parseLicenses(msg.content.toString());
          break;
      }

    } catch (err){
      logger.error('Error handling licensing message: ' + err.message);
    }
  }
}

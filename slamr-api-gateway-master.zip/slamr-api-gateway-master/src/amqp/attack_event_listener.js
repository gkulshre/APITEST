/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import RMQBase from './rmq_base';

export default class AttackEventListener extends RMQBase {
  constructor() {
    super(process.env.RABBITMQ_ATTACK_EVENT_QUEUE, process.env.RABBITMQ_ATTACK_EVENT_ROUTE, 'Attack Event Listener');
  }

  handle_message(msg){
    try {
      let result = JSON.parse(msg.content.toString());
      let domain_id = result.domain_id;

      logger.debug(`Received Attack Event '${JSON.stringify(result)}' for '${domain_id}'`);
      io.sendAttackMessage(domain_id, JSON.stringify(result));
    } catch (err){
      logger.error(`Error parsing Attack Event Message:  '${err.message}'`);
    }
  }
}

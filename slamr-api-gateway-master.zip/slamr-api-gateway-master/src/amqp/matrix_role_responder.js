/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import RMQBase from './rmq_base';

export default class MatrixRoleResponder extends RMQBase {
  constructor() {
    super(process.env.RABBITMQ_MATRIX_ROLE_RESP_QUEUE, process.env.RABBITMQ_MATRIX_ROLE_RESP_ROUTE, 'Matrix Role Responder');
  }

  handle_message(msg){
    try {
      logger.debug('received message on ' + msg.fields.routingKey);
      switch (msg.fields.routingKey) {
        case process.env.RABBITMQ_MATRIX_ROLE_RESP_QUEUE:
          security.matrix.rm.parseResult(msg.content.toString());
          break;
      }

    } catch (err){
      logger.error('Error handling message: ' + err.message);
    }
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import UUID from 'uuid/v4';
import logger from '../util/logger';
import Formatting from '../util/formatting';

export default class Publisher {
  constructor(rmqC) {
    this.rmqC = rmqC;
  }

  sendRequest(exchange, route, data, options){
    if (this.rmqC.connected){
      this.rmqC.channel.publish(exchange, route, data, options);
    } else {
      // TODO: Queue for pending mesages
    }
  }

  sendBlindRequest(data = {}, route){
    let uid = UUID();
    try {

      let options = {
        correlationId: uid,
        replyTo: process.env.RABBITMQ_BLIND_QUEUE,
      };
      /* eslint-disable new-cap */
      this.sendRequest(process.env.RABBITMQ_EXCH, route, new Buffer.from(JSON.stringify(data)), options);
      /* eslint-enable new-cap */
      logger.debug(`Blind Request sent: '${route}' with ID: '${uid}'`);

    } catch (err) {
      logger.error(`Error sending blind message on '${route}' with error: '${err.message}'`);
    }
  }

  sendSyncRequest(res, data = {}, route){
    let uid = UUID();
    try {
      syncQueue.set(uid, res);
      let options = {
        correlationId: uid,
        replyTo: process.env.RABBITMQ_SYNC_RESP_QUEUE,
      };
      /* eslint-disable new-cap */
      this.sendRequest(process.env.RABBITMQ_EXCH, route, new Buffer.from(JSON.stringify(data)), options);
      /* eslint-enable new-cap */
      logger.debug(`Sync Request sent: '${route}' with ID: '${uid}'`);

    } catch (err) {
      logger.error(`Error sending message on '${route}' with error: '${err.message}'`);
      if (syncQueue.has(uid)) {
        syncQueue.delete(uid);
      }
      this.send_error(res, err.message);
    }
  }

  sendOrchSyncRequest(req, res, data = {}, route, callback, OPTS){
    let uid = UUID();
    try {
      let oItem = {};
      oItem.req = req.body;
      oItem.res = res;
      oItem.last_Route = route;
      oItem.cb = callback;
      oItem.opts = OPTS;
      orchSyncQueue.set(uid, oItem);
      let options = {
        correlationId: uid,
        replyTo: process.env.RABBITMQ_ORCH_SYNC_RESP_QUEUE,
      };
      /* eslint-disable new-cap */
      this.sendRequest(process.env.RABBITMQ_EXCH, route, new Buffer.from(JSON.stringify(data)), options);
      /* eslint-enable new-cap */
      logger.debug(`Orch Request sent: '${route}' with ID: '${uid}'`);

    } catch (err) {
      logger.error(`Error sending message on '${route}' with error: '${err.message}'`);
      if (orchSyncQueue.has(uid)) {
        orchSyncQueue.delete(uid);
      }
      this.send_error(res, err.message);
    }
  }

  sendOrchAsyncRequest(data = {}, route){
    let uid = UUID();
    try {
      let options = {
        correlationId: uid,
        replyTo: process.env.RABBITMQ_ASYNC_EVENT_LISTENER_QUEUE,
      };
      /* eslint-disable new-cap */
      this.sendRequest(process.env.RABBITMQ_EXCH, route, new Buffer.from(JSON.stringify(data)), options);
      /* eslint-enable new-cap */
      logger.debug(`Orch Async Request sent: '${route}' with ID: '${uid}'`);

    } catch (err) {
      logger.error(`Error sending orch async message on '${route}' with error: '${err.message}'`);
      if (orchSyncQueue.has(uid)) {
        orchSyncQueue.delete(uid);
      }
      // Emit error for task
    }
  }

  send_error(res, message, status = 500, type = 'Internal Server Error'){
    try {
      if (res.headersSent === false){
        console.log('Publishing Error');
        res.status(status).send(Formatting.formatError(status, type, message));
      }
    } catch (err) {
      logger.error(`Unable to send error message:: ${err.message}`);
    }
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

import EventTagRoutes from './event_tag_routes';

const routes = [
  { verb: 'get', route: '/', topic: topics.ATTACK_EVENT.LIST },
  { verb: 'get', route: '/:id', topic: topics.ATTACK_EVENT.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.ATTACK_EVENT.CREATE },
  { verb: 'put', route: '/:id', topic: topics.ATTACK_EVENT.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.ATTACK_EVENT.DELETE },
  { verb: 'post', route: '/:id/start', topic: topics.ATTACK_EVENT.START },
  { verb: 'post', route: '/:id/stop', topic: topics.ATTACK_EVENT.STOP },
];

export default class AttackEventRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/:event_id/event-tags', new EventTagRoutes().getRouter());
    router.use('/event-tags', new EventTagRoutes().getRouter());
    super(router, routes);
  }
}

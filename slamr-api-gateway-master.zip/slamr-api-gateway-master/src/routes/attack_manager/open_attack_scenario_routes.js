/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

const routes = [
  { verb: 'get', route: '/', topic: topics.OPEN_ATTACK_SCENARIO.LIST },
  { verb: 'get', route: '/:id', topic: topics.OPEN_ATTACK_SCENARIO.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.OPEN_ATTACK_SCENARIO.CREATE },
  { verb: 'put', route: '/:id', topic: topics.OPEN_ATTACK_SCENARIO.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.OPEN_ATTACK_SCENARIO.DELETE },
];

export default class OpenAttackScenarioRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

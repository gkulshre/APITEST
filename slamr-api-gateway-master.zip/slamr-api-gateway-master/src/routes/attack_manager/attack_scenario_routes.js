/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

const routes = [
  { verb: 'get', route: '/', topic: topics.ATTACK_SCENARIO.LIST },
  { verb: 'get', route: '/:id', topic: topics.ATTACK_SCENARIO.RETRIEVE },
  { verb: 'post', route: '/:id/playbook', topic: topics.ATTACK_SCENARIO.PLAYBOOK },
  { verb: 'post', route: '/', topic: topics.ORCHESTRATION.ATTACK.CREATE },
  { verb: 'put', route: '/:id', topic: topics.ORCHESTRATION.ATTACK.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.ORCHESTRATION.ATTACK.DELETE },
  { verb: 'post', route: '/:id/start', topic: topics.ATTACK_SCENARIO.START },
  { verb: 'post', route: '/:id/stop', topic: topics.ATTACK_SCENARIO.STOP },
  { verb: 'post', route: '/:id/import', topic: topics.ATTACK_SCENARIO.IMPORT },
];

export default class AttackScenarioRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

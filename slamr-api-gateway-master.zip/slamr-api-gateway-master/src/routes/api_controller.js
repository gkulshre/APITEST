/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */


exports.retrieve = (req, res) => {

  try {
    let sendpoints = {};
    const ordered = {};
    const output = [];
    endpoints.forEach((item) => {

      if (item['path'] in sendpoints){
        sendpoints[item['path']].push(item['methods']);
      } else {
        sendpoints[item['path']] = [];
        sendpoints[item['path']].push(item['methods']);
      }
    });

    Object.keys(sendpoints).sort().forEach(function(key) {
      ordered[key] = sendpoints[key];
    });

    Object.getOwnPropertyNames(ordered).forEach((item) => {
      output.push(`${item}:  [${ordered[item].toString()}]`);
    });

    res.status(200).send(output);

  } catch (err) {
    if (res.headersSent === false) {

      res.status(500).send('Error building routes');
    }
  }
};

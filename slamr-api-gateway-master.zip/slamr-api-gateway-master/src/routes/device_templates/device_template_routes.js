/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

const routes = [
  { verb: 'get', route: '/', topic: topics.DEVICE_TEMPLATE.LIST },
  { verb: 'get', route: '/:id', topic: topics.DEVICE_TEMPLATE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.ORCHESTRATION.DEVICE_TEMPLATE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.ORCHESTRATION.DEVICE_TEMPLATE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.ORCHESTRATION.DEVICE_TEMPLATE.DELETE },
];

export default class DeviceTemplateRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

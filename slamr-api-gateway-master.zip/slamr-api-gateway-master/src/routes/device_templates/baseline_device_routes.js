/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

const routes = [
  { verb: 'get', route: '/', topic: topics.BASELINE_DEVICE.LIST },
  { verb: 'get', route: '/:id', topic: topics.BASELINE_DEVICE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.BASELINE_DEVICE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.BASELINE_DEVICE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.BASELINE_DEVICE.DELETE },
];

export default class BaselineDeviceRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

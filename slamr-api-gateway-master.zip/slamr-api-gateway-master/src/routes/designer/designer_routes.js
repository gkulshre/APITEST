/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import ProjectDesignerRoutes from './project_designer/project_designer_routes';
import SystemDesignerRoutes from './system_designer/system_designer_routes';

const routes = [];

export default class DesignerRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    router.use('/projects', new ProjectDesignerRoutes().getRouter());
    router.use('/systems', new SystemDesignerRoutes().getRouter());
    super(router, routes);
  }
}

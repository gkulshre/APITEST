/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.DESIGNER.INFRAVLAN.LIST },
  { verb: 'get', route: '/:id', topic: topics.DESIGNER.INFRAVLAN.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.DESIGNER.INFRAVLAN.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DESIGNER.INFRAVLAN.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DESIGNER.INFRAVLAN.DELETE },
  { verb: 'post', route: '/:vlan_id/link_port/:id', topic: topics.DESIGNER.INFRAVLAN.LINKPORT },
  { verb: 'post', route: '/:vlan_id/unlink_port/:id', topic: topics.DESIGNER.INFRAVLAN.UNLINKPORT },
  { verb: 'post', route: '/:vlan_id/link_network/:id', topic: topics.DESIGNER.INFRAVLAN.LINKNETWORK },
  { verb: 'post', route: '/:vlan_id/unlink_network/:id', topic: topics.DESIGNER.INFRAVLAN.UNLINKNETWORK },
];

export default class SystemInfraVLANRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

import SystemInfraInterfaceRoutes from "./system_infra_interface_routes";
import SystemInfraBridgeRoutes from "./system_infra_bridge_routes";

const routes = [
  { verb: 'get', route: '/', topic: topics.DESIGNER.INFRANODE.LIST },
  { verb: 'get', route: '/:id', topic: topics.DESIGNER.INFRANODE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.DESIGNER.INFRANODE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DESIGNER.INFRANODE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DESIGNER.INFRANODE.DELETE },
];

export default class SystemInfraNodeRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    router.use('/:infra_node_id/interfaces', new SystemInfraInterfaceRoutes().getRouter());
    router.use('/:infra_node_id/bridges', new SystemInfraBridgeRoutes().getRouter());
    super(router, routes);
  }
}

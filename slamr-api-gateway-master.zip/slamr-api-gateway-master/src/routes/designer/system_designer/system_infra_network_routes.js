/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

import SystemInfraSupportedNetworkRoutes from './system_infra_supported_network_routes';

const routes = [
  { verb: 'get', route: '/', topic: topics.DESIGNER.INFRANETWORK.LIST },
  { verb: 'get', route: '/:id', topic: topics.DESIGNER.INFRANETWORK.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.DESIGNER.INFRANETWORK.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DESIGNER.INFRANETWORK.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DESIGNER.INFRANETWORK.DELETE },
  { verb: 'post', route: '/:network_id/link_vlan/:id', topic: topics.DESIGNER.INFRANETWORK.LINKVLAN },
  { verb: 'post', route: '/:network_id/unlink_vlan/:id', topic: topics.DESIGNER.INFRANETWORK.UNLINKVLAN },
];

export default class SystemInfraNetworkRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    router.use('/:infra_network_id/supported_networks', new SystemInfraSupportedNetworkRoutes().getRouter());
    super(router, routes);
  }
}

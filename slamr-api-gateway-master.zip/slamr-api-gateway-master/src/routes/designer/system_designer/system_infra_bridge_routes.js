/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

import SystemInfraNetworkRoutes from './system_infra_network_routes';
import SystemInfraPortRoutes from './system_infra_port_routes';

const routes = [
  { verb: 'get', route: '/', topic: topics.DESIGNER.INFRABRIDGE.LIST },
  { verb: 'get', route: '/:id', topic: topics.DESIGNER.INFRABRIDGE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.DESIGNER.INFRABRIDGE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DESIGNER.INFRABRIDGE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DESIGNER.INFRABRIDGE.DELETE },
];

export default class SystemInfraBridgeRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    router.use('/:infra_bridge_id/networks', new SystemInfraNetworkRoutes().getRouter());
    router.use('/:infra_bridge_id/ports', new SystemInfraPortRoutes().getRouter());
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

import SystemInfraNodesRoutes from './system_infra_node_routes';
import SystemInfraVLANRoutes from './system_infra_vlan_routes';

const routes = [
  { verb: 'get', route: '/', topic: topics.DESIGNER.SYSTEMDESIGN.LIST },
  { verb: 'get', route: '/:id', topic: topics.DESIGNER.SYSTEMDESIGN.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.DESIGNER.SYSTEMDESIGN.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DESIGNER.SYSTEMDESIGN.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DESIGNER.SYSTEMDESIGN.DELETE },
];

export default class SystemDesignerRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    router.use('/:infra_system_id/nodes', new SystemInfraNodesRoutes().getRouter());
    router.use('/:infra_system_id/vlans', new SystemInfraVLANRoutes().getRouter());
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.DESIGNER.INFRAPORT.LIST },
  { verb: 'get', route: '/:id', topic: topics.DESIGNER.INFRAPORT.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.DESIGNER.INFRAPORT.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DESIGNER.INFRAPORT.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DESIGNER.INFRAPORT.DELETE },
  { verb: 'post', route: '/:port_id/link_interface/:id', topic: topics.DESIGNER.INFRAPORT.LINKINTERFACE },
  { verb: 'post', route: '/:port_id/unlink_interface/:id', topic: topics.DESIGNER.INFRAPORT.UNLINKINTERFACE },
  { verb: 'post', route: '/:port_id/link_vlan/:id', topic: topics.DESIGNER.INFRAPORT.LINKVLAN },
  { verb: 'post', route: '/:port_id/unlink_vlan/:id', topic: topics.DESIGNER.INFRAPORT.UNLINKVLAN },
];

export default class SystemInfraPortRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.DESIGNER.TRAFFICPROFILE.LIST },
  { verb: 'get', route: '/:id', topic: topics.DESIGNER.TRAFFICPROFILE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.DESIGNER.TRAFFICPROFILE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DESIGNER.TRAFFICPROFILE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DESIGNER.TRAFFICPROFILE.DELETE }];

export default class FolderTrafficRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

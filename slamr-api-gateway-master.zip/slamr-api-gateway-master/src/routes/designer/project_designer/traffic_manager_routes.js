/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.TRAFFICMANAGER.LISTPROFILES },
  { verb: 'get', route: '/:id', topic: topics.TRAFFICMANAGER.RETRIEVEPROFILE },
  { verb: 'post', route: '/', topic: topics.ORCHESTRATION.PROJECTDESIGNER.TRAFFICMANAGER.CREATE },
  { verb: 'put', route: '/:id', topic: topics.ORCHESTRATION.PROJECTDESIGNER.TRAFFICMANAGER.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.ORCHESTRATION.PROJECTDESIGNER.TRAFFICMANAGER.DELETE },
];
export default class OrchestrationTrafficManagerRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

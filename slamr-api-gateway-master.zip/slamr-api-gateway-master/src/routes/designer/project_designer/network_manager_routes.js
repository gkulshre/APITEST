/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.DESIGNER.NETWORK.LIST },
  { verb: 'get', route: '/:id', topic: topics.DESIGNER.NETWORK.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.DESIGNER.NETWORK.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DESIGNER.NETWORK.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DESIGNER.NETWORK.DELETE },
];

export default class ProjectNetworkRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

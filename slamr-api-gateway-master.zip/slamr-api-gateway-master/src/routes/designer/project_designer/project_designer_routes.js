/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

import ProjectCustomerRoutes from './project_customer_routes';
import ProjectDomainRoutes from './project_domain_routes';
import ProjectAuditRoutes from './project_audit_routes';
import ProjectExportRoutes from './project_exports_routes';

const routes = [
  { verb: 'get', route: '/', topic: topics.DESIGNER.PROJECT.LIST },
  { verb: 'get', route: '/:id', topic: topics.DESIGNER.PROJECT.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.DESIGNER.PROJECT.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DESIGNER.PROJECT.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DESIGNER.PROJECT.DELETE },
  { verb: 'post', route: '/:id/deploy', topic: topics.DESIGNER.PROJECT.DEPLOY },
  { verb: 'post', route: '/:id/duplicate', topic: topics.DESIGNER.PROJECT.DUPLICATE },
];

export default class ProjectDesignerRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/customers', new ProjectCustomerRoutes().getRouter());
    router.use('/exports', new ProjectExportRoutes().getRouter());
    router.use('/:project_id/domains', new ProjectDomainRoutes().getRouter());
    router.use('/:project_id/audits', new ProjectAuditRoutes().getRouter());
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

import DeviceVirtualNicRoutes from './device_virtual_nic_routes';

const routes = [
  { verb: 'post', route: '/', topic: topics.DESIGNER.DEVICE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DESIGNER.DEVICE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DESIGNER.DEVICE.DELETE },
];

export default class FolderDeviceRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/:device_id/virtual_nic', new DeviceVirtualNicRoutes().getRouter());
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

import VirtualNicIPAddressRoutes from './virtual_nic_ip_address_routes';

const routes = [
  { verb: 'get', route: '/', topic: topics.DESIGNER.VIRTUALNIC.LIST },
  { verb: 'get', route: '/:id', topic: topics.DESIGNER.VIRTUALNIC.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.DESIGNER.VIRTUALNIC.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DESIGNER.VIRTUALNIC.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DESIGNER.VIRTUALNIC.DELETE }];

export default class DeviceVirtualNicRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/:virtual_nic_id/ip_addresses', new VirtualNicIPAddressRoutes().getRouter());
    super(router, routes);
  }
}

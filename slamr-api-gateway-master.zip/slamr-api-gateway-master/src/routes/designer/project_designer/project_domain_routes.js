/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

import DomainFolderRoutes from './domain_folder_routes';
import OrchestrationTrafficManagerRoutes from './traffic_manager_routes';
import OrchestrationAttackManagerRoutes from './attack_manager_routes';
import OrchestrationDeviceManagerRoutes from './device_manager_routes';
import ProjectNetworkRoutes from './network_manager_routes';

const routes = [
  { verb: 'get', route: '/', topic: topics.DESIGNER.DOMAIN.LIST },
  { verb: 'get', route: '/:id', topic: topics.DESIGNER.DOMAIN.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.DESIGNER.DOMAIN.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DESIGNER.DOMAIN.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DESIGNER.DOMAIN.DELETE },
];

export default class ProjectDomainRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/:domain_id/folders', new DomainFolderRoutes().getRouter());
    router.use('/:domain_id/traffic-profiles', new OrchestrationTrafficManagerRoutes().getRouter());
    router.use('/:domain_id/attack-scenarios', new OrchestrationAttackManagerRoutes().getRouter());
    router.use('/:domain_id/device-templates', new OrchestrationDeviceManagerRoutes().getRouter());
    router.use('/:domain_id/networks', new ProjectNetworkRoutes().getRouter());
    super(router, routes);
  }
}

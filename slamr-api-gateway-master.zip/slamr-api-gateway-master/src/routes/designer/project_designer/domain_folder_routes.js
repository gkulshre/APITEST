/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

import FolderDeviceRoutes from './folder_device_routes';
import FolderAttackRoutes from './folder_attack_routes';
import FolderTrafficRoutes from './folder_traffic_routes';

const routes = [
  { verb: 'get', route: '/', topic: topics.DESIGNER.FOLDER.LIST },
  { verb: 'get', route: '/:id', topic: topics.DESIGNER.FOLDER.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.DESIGNER.FOLDER.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DESIGNER.FOLDER.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DESIGNER.FOLDER.DELETE }];

export default class DomainFolderRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/:parent_id/devices', new FolderDeviceRoutes().getRouter());
    router.use('/:parent_id/attacks', new FolderAttackRoutes().getRouter());
    router.use('/:parent_id/traffic', new FolderTrafficRoutes().getRouter());
    super(router, routes);
  }
}

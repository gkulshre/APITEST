/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import DeviceTemplateRoutes from '../device_templates/device_template_routes';
import BaselineDeviceRoutes from '../device_templates/baseline_device_routes';
import { DeviceSnapshotRoutes } from '../device_manager/device_snapshot_routes';
import { SnapshotGroupRoutes } from '../device_manager/snapshot_group_routes';
import { DeviceInterfaceRoutes } from '../device_manager/device_interface_routes';
import { DeviceFolderRoutes } from '../device_manager/device_folder_routes';
import { DeviceOperationRoutes } from '../device_manager/device_operation_routes';

import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.DEVICE.LIST },
  { verb: 'get', route: '/:id', topic: topics.DEVICE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.ORCHESTRATION.DEVICE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.ORCHESTRATION.DEVICE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.ORCHESTRATION.DEVICE.DELETE },
  { verb: 'post', route: '/:id/start', topic: topics.DEVICE.START },
  { verb: 'post', route: '/:id/poweroff', topic: topics.DEVICE.POWEROFF },
  { verb: 'post', route: '/:id/shutdown', topic: topics.DEVICE.SHUTDOWN },
  { verb: 'post', route: '/:id/reboot', topic: topics.DEVICE.REBOOT },
  { verb: 'post', route: '/:id/enable-rdp', topic: topics.DEVICE.ENABLERDP },
  { verb: 'post', route: '/:id/disable-rdp', topic: topics.DEVICE.DISABLERDP },
  { verb: 'post', route: '/:id/revert', topic: topics.DEVICE.REVERT },
  { verb: 'post', route: '/:id/export', topic: topics.DEVICE.EXPORT },
  { verb: 'post', route: '/:id/refresh', topic: topics.DEVICE.REFRESH },
];

export default class DomainDeviceRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/device-templates', new DeviceTemplateRoutes().getRouter());
    router.use('/baseline-device', new BaselineDeviceRoutes().getRouter());
    router.use('/:vd_id/snapshots', new DeviceSnapshotRoutes().getRouter());
    router.use('/:vd_id/interfaces', new DeviceInterfaceRoutes().getRouter());
    router.use('/folders', new DeviceFolderRoutes().getRouter());
    router.use('/operations', new DeviceOperationRoutes().getRouter());
    router.use('/snapshot-groups', new SnapshotGroupRoutes().getRouter());
    super(router, routes);
  }
}

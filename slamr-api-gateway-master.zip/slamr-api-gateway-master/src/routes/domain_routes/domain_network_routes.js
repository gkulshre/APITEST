/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
import NetworkManagerControlRoutes from '../network_manager/network_manager_control_routes';

const routes = [
  { verb: 'get', route: '/', topic: topics.NETMANAGER.LIST },
  { verb: 'get', route: '/:id', topic: topics.NETMANAGER.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.ORCHESTRATION.NETWORK.CREATE },
  { verb: 'put', route: '/:id', topic: topics.ORCHESTRATION.NETWORK.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.ORCHESTRATION.NETWORK.DELETE },
];

export default class DomainNetworkRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/', new NetworkManagerControlRoutes().getRouter());
    super(router, routes);
  }
}

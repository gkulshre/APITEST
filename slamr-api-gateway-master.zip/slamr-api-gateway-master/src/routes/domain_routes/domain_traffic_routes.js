/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { Router } from 'express';
import topics from '../topics';
import { RouterBase } from '../base_classes/router_base';
import TrafficTypeRoutes from '../traffic_manager/traffic_type_routes';
import TrafficControllerRoutes from '../traffic_controller/traffic_controller_routes';

const routes = [
  { verb: 'get', route: '/', topic: topics.TRAFFICMANAGER.LISTPROFBYDOM },
  { verb: 'get', route: '/:id', topic: topics.TRAFFICMANAGER.RETRIEVEPROFILE },
  { verb: 'post', route: '/export', topic: topics.TRAFFICMANAGER.EXPORTPROFILE },
  { verb: 'post', route: '/import', topic: topics.TRAFFICMANAGER.IMPORTPROFILE },
  { verb: 'post', route: '/', topic: topics.ORCHESTRATION.TRAFFIC.CREATE },
  { verb: 'put', route: '/:id', topic: topics.ORCHESTRATION.TRAFFIC.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.ORCHESTRATION.TRAFFIC.DELETE },
];

export default class TrafficManagerRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/:profile_id/traffic_types', new TrafficTypeRoutes().getRouter());
    router.use('/traffic_controller', new TrafficControllerRoutes().getRouter());
    super(router, routes);
  }
}

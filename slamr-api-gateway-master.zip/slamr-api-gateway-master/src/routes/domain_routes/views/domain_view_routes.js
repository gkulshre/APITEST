/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
/* */

import DeviceViewRoutes from './device_view_routes';
import NetworkViewRoutes from './network_view_routes';
import AttackViewRoutes from './attack_view_routes';
import TrafficViewRoutes from './traffic_view_routes';

const routes = [];

export default class DomainViewRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    router.use('/devices', new DeviceViewRoutes().getRouter());
    router.use('/networks', new NetworkViewRoutes().getRouter());
    router.use('/attacks', new AttackViewRoutes().getRouter());
    router.use('/traffic', new TrafficViewRoutes().getRouter());
    super(router, routes);
  }
}

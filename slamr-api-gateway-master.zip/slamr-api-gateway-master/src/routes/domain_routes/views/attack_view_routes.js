/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';
/* */

const routes = [
  { verb: 'get', route: '/', topic: topics.DOMAIN.ATTACK.LIST },
  { verb: 'get', route: '/:id', topic: topics.DOMAIN.ATTACK.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.DOMAIN.ATTACK.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DOMAIN.ATTACK.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DOMAIN.ATTACK.DELETE },
];

export default class AttackViewRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

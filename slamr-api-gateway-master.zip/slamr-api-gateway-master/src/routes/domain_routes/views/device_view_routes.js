/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';
/* */

const routes = [
  { verb: 'get', route: '/', topic: topics.DOMAIN.DEVICE.LIST },
  { verb: 'get', route: '/:id', topic: topics.DOMAIN.DEVICE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.DOMAIN.DEVICE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DOMAIN.DEVICE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DOMAIN.DEVICE.DELETE },
];

export default class DeviceViewRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';
/* */

const routes = [
  { verb: 'get', route: '/', topic: topics.DOMAIN.NETWORK.LIST },
  { verb: 'get', route: '/:id', topic: topics.DOMAIN.NETWORK.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.DOMAIN.NETWORK.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DOMAIN.NETWORK.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.DOMAIN.NETWORK.DELETE },
];

export default class NetworkViewRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

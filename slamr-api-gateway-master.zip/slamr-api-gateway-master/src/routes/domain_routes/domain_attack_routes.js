/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
/* */

import AttackScenarioRoutes from '../attack_manager/attack_scenario_routes';
import AttackTemplateRoutes from '../attack_template/attack_template_routes';
import AttackEventRoutes from '../attack_manager/attack_event_routes';
import AttackControllerRoutes from '../attack_controller/attack_controller_routes';

const routes = [];

export default class DomainAttackRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/attack-scenarios', new AttackScenarioRoutes().getRouter());
    router.use('/attack-templates', new AttackTemplateRoutes().getRouter());
    router.use('/attack-events', new AttackEventRoutes().getRouter());
    router.use('/attack-controller', new AttackControllerRoutes().getRouter());
    super(router, routes);
  }
}

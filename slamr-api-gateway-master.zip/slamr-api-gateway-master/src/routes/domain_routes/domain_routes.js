/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

import DomainAttackRoutes from './domain_attack_routes';
import DomainNetworkRoutes from './domain_network_routes';
import DomainTrafficRoutes from './domain_traffic_routes';
import DomainDeviceRoutes from './domain_device_routes';
import DomainViewRoutes from './views/domain_view_routes';
import OnDemandRoutes from '../on_demand_manager/on_demand_routes';
import CIFRoutes from '../cif/cif_routes';
import CLAFRoutes from '../claf/claf_routes';
import ComponentTemplateRoutes from '../component_template/component_template_routes';

const routes = [
  { verb: 'get', route: '/', topic: topics.DOMAIN.LIST },
  { verb: 'get', route: '/internet', topic: topics.DOMAIN.LIST_INTERNET },
  { verb: 'get', route: '/:id', topic: topics.DOMAIN.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.ORCHESTRATION.DOMAIN.CREATE },
  { verb: 'put', route: '/:id', topic: topics.DOMAIN.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.ORCHESTRATION.DOMAIN.DELETE },
  { verb: 'post', route: '/:id/initialize', topic: topics.SIM_MANAGER.DOMAIN.INITIALIZE },
  { verb: 'post', route: '/:id/deinitialize', topic: topics.SIM_MANAGER.DOMAIN.DEINITIALIZE },
  { verb: 'post', route: '/:id/state', topic: topics.SIM_MANAGER.DOMAIN.STATE },
  { verb: 'get', route: '/:id/adhoc_sims', topic: topics.SIM_MANAGER.ADHOC.LIST },
];

export default class DomainRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/:domain_id/devices', new DomainDeviceRoutes().getRouter());
    router.use('/:domain_id/networks', new DomainNetworkRoutes().getRouter());
    router.use('/:domain_id/attacks', new DomainAttackRoutes().getRouter());
    router.use('/:domain_id/traffic', new DomainTrafficRoutes().getRouter());
    router.use('/:domain_id/views', new DomainViewRoutes().getRouter());
    router.use('/:domain_id/on-demand', new OnDemandRoutes().getRouter());
    router.use('/:domain_id/cif', new CIFRoutes().getRouter());
    router.use('/:domain_id/claf', new CLAFRoutes().getRouter());
    router.use('/:domain_id/component-templates', new ComponentTemplateRoutes().getRouter());
    super(router, routes);
  }
}

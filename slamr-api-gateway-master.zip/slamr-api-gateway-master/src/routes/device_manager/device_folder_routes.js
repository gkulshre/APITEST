/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

const routes = [
  { verb: 'post', route: '/:id/start', topic: topics.DEVICE.FOLDERS.START },
  { verb: 'post', route: '/:id/shutdown', topic: topics.DEVICE.FOLDERS.SHUTDOWN },
  { verb: 'post', route: '/:id/poweroff', topic: topics.DEVICE.FOLDERS.POWEROFF },
  { verb: 'post', route: '/:id/revert', topic: topics.DEVICE.FOLDERS.REVERT },
  { verb: 'post', route: '/:id/snapshot', topic: topics.DEVICE.FOLDERS.SNAPSHOT },
];

export class DeviceFolderRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

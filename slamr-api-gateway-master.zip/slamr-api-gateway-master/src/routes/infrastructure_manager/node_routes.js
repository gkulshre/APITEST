/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

import InterfaceRoutes from './interface_routes';
import { SwitchRoutes } from './switch_routes';

const routes = [
  { verb: 'get', route: '/', topic: topics.INFRAMANAGER.NODE.LIST },
  { verb: 'get', route: '/:node_id/stats', topic: topics.INFRAMANAGER.NODE.RETRIEVE},
];

export default class NodeRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/:node_id/interfaces', new InterfaceRoutes().getRouter());
    router.use('/:node_id/switches', new SwitchRoutes().getRouter());
    super(router, routes);
  }
}

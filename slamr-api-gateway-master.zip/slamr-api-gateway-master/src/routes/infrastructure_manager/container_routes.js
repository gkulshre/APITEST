/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.INFRAMANAGER.CONTAINER.LIST },
  { verb: 'get', route: '/status', topic: topics.INFRAMANAGER.CONTAINER.STATUS },
  { verb: 'post', route: '/:id/start', topic: topics.INFRAMANAGER.CONTAINER.START },
  { verb: 'post', route: '/:id/stop', topic: topics.INFRAMANAGER.CONTAINER.STOP },
  { verb: 'post', route: '/:id/restart', topic: topics.INFRAMANAGER.CONTAINER.RESTART },
];

export default class ContainerRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

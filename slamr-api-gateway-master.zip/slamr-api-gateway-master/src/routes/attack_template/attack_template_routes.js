/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */
import TemplateTagRoutes from '../attack_template/template_tag_routes';

const routes = [
  { verb: 'get', route: '/', topic: topics.ATTACK_TEMPLATE.LIST },
  { verb: 'get', route: '/:id', topic: topics.ATTACK_TEMPLATE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.ATTACK_TEMPLATE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.ATTACK_TEMPLATE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.ATTACK_TEMPLATE.DELETE },
];

export default class AttackTemplateRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    router.use('/:attack_template_id/template-tags', new TemplateTagRoutes().getRouter());
    router.use('/template-tags', new TemplateTagRoutes().getRouter());
    super(router, routes);
  }
}

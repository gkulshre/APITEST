/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import fs from 'fs';
import logger from '../../util/logger';
import { Router } from 'express';

function errorCase(res, error_message, status = 500) {
  res.setHeader('Content-Type', 'application/json');
  res.status(status).end(JSON.stringify({ message: error_message }));
}

export default class LinksRoutes {
  constructor() {
    this.router = new Router({ mergeParams: true });
    logger.debug('Links Initialized');
  }

  getRouter() {
    logger.debug('Setting up Link Post');
    this.router.post('/', (req, res, next) => {
      let source = req.header('x-forwarded-for') || req.connection.remoteAddress || req.ip;
      logger.info(`Download Link Request Received From ${source} with payload ${req.body}`);
      let absPath = req.body.path;
      let ip = process.env.SERVER_IP;
      let basePath = process.env.DOWNLOAD_SERVER_BASE_PATH;
      let port = process.env.DOWNLOAD_SERVER_PORT;
      let urlPath = absPath.split(basePath).join('');
      try {
        if (!fs.existsSync(absPath)) {
          errorCase(res, 'Target File does not exist', 404);
        }
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ link: `http://${ip}:${port}${urlPath}` }));
      } catch (error) {
        errorCase(res, error.message);
      }
    });
    logger.debug('Finished Setting up Linked Post');

    return this.router;
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import LinksRoutes from './links_routes';
import PlaybookRoute from './playbook_route';
import AttackPlanFileRoute from './attackplanfile_route';
import TrafficProfileRoute from './traffic_route';
import DeviceRoute from './device_route';
import ProjectDesignerRoute from './project_designer_route';

const routes = [];

export default class DownloadRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/playbook', new PlaybookRoute().getRouter());
    router.use('/links', new LinksRoutes().getRouter());
    router.use('/traffic', new TrafficProfileRoute().getRouter());
    // Attack Plan download route not fully implemented
    router.use('/attackplan', new AttackPlanFileRoute().getRouter());
    router.use('/device', new DeviceRoute().getRouter());
    router.use('/projectDesigner', new ProjectDesignerRoute().getRouter());
    super(router, routes);
  }
}

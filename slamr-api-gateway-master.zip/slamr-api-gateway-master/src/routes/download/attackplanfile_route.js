/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import path from 'path';
import logger from '../../util/logger';
import fs from 'fs';
import { Router } from 'express';

function errorCase(res, error_message, status = 500) {
  logger.debug(`Attack Plan File download Error '${error_message}'`);
  res.setHeader('Content-Type', 'application/json');
  res.status(status).end(JSON.stringify({ message: error_message }));
}

export default class AttackPlanFileRoute {
  constructor() {
    this.router = new Router({ mergeParams: true });
    logger.debug('Download Initialized');
  }

  getRouter() {
    this.router.get('/:filename', (req, res, next) => {
      let source = req.header('x-forwarded-for') || req.connection.remoteAddress || req.ip;
      logger.info(`Download Attack Plan File Request Received From ${source} with filename ${req.params.filename}`);
      let dlPath = path.join(process.env.DOWNLOAD_SERVER_TARGETS_ATTACK_PLAN, req.params.filename);

      try {
        if (fs.existsSync(dlPath)) {
          res.set({
            'Content-disposition': `attachment: filename=${req.params.filename}`,
            'Content-type': 'application/json',
          });
          res.download(dlPath, req.params.filename, err => {
            if (err) {
              errorCase(res, err.message);
            }
          });
        } else {
          errorCase(res, 'Target File does not exist', 404);
        }
      } catch (error) {
        errorCase(res, error.message);
      }
    });

    return this.router;
  }
}

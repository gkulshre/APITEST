/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'post', route: '/:id/start', topic: topics.NETMANAGER.START },
  { verb: 'post', route: '/:id/stop', topic: topics.NETMANAGER.STOP },
  { verb: 'post', route: '/:id/restart', topic: topics.NETMANAGER.RESTART },
  { verb: 'post', route: '/:id/add_mirror', topic: topics.NETMANAGER.ADD_MIRROR },
  { verb: 'post', route: '/:id/remove_mirror', topic: topics.NETMANAGER.REMOVE_MIRROR },
  { verb: 'post', route: '/:network_id/interfaces/:id', topic: topics.NETMANAGER.ADD_INTERFACE },
  { verb: 'delete', route: '/:network_id/interfaces/:id', topic: topics.NETMANAGER.REMOVE_INTERFACE },
];

export default class NetworkManagerControlRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

const routes = [
  { verb: 'get', route: '/', topic: topics.DEVICE_TEMPLATE.LIST },
];

export default class NodeRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }

  router(){
    const router = new Router();

    router.get('/switches', async(req, res, next) => {
      const data = Object.assign(req.params, req.query, req.body);
      super.sendRequest(req, res, next, data, '*.network.manager.*.list.switches.request');
    });

    router.get('/:nodeID/interfaces', async(req, res, next) => {
      const data = { node_id: parseInt(req.params.nodeID, 10) };
      super.sendRequest(req, res, next, data, '*.network.manager.*.list.physical_interfaces.request');
    });

    router.use(super.router());

    return router;
  }
}

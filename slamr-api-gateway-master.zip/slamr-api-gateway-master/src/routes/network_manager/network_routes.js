/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { Router } from 'express';
import { RouterBase } from '../base_classes/router_base';
import topics from '../topics';


const routes = [
  { verb: 'get', route: '/', topic: topics.NETMANAGER.LIST },
  { verb: 'get', route: '/:id', topic: topics.NETMANAGER.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.NETMANAGER.CREATE },
  { verb: 'put', route: '/:id', topic: topics.NETMANAGER.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.NETMANAGER.DELETE },
];

// TODO setup async request
export default class NetworkRoutes extends RouterBase {
  constructor() {
    const router = new Router();
    super(router, routes);
  }
}

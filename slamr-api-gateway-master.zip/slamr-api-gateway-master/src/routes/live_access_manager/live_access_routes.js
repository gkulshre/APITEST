/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

const routes = [
  { verb: 'post', route: '/start', topic: topics.LIVE_ACCESS.START },
  { verb: 'post', route: '/finish', topic: topics.LIVE_ACCESS.FINISH },
  { verb: 'post', route: '/finish-all', topic: topics.LIVE_ACCESS.FINISH_ALL },
  { verb: 'post', route: '/stop-all', topic: topics.LIVE_ACCESS.STOP_ALL },
];

export default class LiveAccessRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

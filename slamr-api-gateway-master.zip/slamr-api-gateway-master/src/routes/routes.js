/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import express from 'express';
import timeout from 'connect-timeout';
import ApiController from './api_controller';
import AuthRoutes from './authentication/auth_routes';
import DomainRoutes from './domain_routes/domain_routes';
import ImageRoutes from './image_manager/image_routes';
import ComponentTemplateRoutes from './component_template/component_template_routes';
import LookupsRoutes from './lookups/lookups_routes';
import logger from '../util/logger';
import OpenAttackScenarioRoutes from './attack_manager/open_attack_scenario_routes';
import OpenAttackEventRoutes from './attack_manager/open_attack_event_routes';
import OpenAttackTemplateRoutes from './attack_template/open_attack_template_routes';
import DesignerRoutes from './designer/designer_routes';
import LiveAccessRoutes from './live_access_manager/live_access_routes';
import LicenseManagerRoutes from './license_manager/license_manager_routes';
import LoggingServiceRoutes from './logging_service/logging_service_routes';
import BackupRoutes from './backup_manager/backup_routes';
import OpenTrafficProfileRoutes from './traffic_manager/open_traffic_profile_routes';
import TrafficTemplateRoutes from './traffic_manager/traffic_profile_template_routes';
import AttackControllerRoutes from './attack_controller/attack_controller_routes';
import NetworkRoutes from './network_manager/network_routes.js';
import InfrastructureManagerRoutes from './infrastructure_manager/infrastructure_manager_routes';
import DownloadRoutes from './download/download_routes';
let ping = require('./util/ping');


export const apiRoutes = () => { // Need to get instance of RMQ into the routes

  const router = new express.Router();
  router.use(timeout(process.env.SERVER_REQ_TIMEOUT));

  /* root routes */
  router.route('/').get(ApiController.retrieve);

  /* auth routes */
  router.use('/auth', new AuthRoutes().getRouter());

  /* status routes */
  router.use('/ping', ping);

  // TODO Add device manager routes
  try {
    router.use('/core/domains', new DomainRoutes().getRouter());
    router.use('/core/live-access', new LiveAccessRoutes().getRouter());
    router.use('/core/backups', new BackupRoutes().getRouter());
    router.use('/core/images', new ImageRoutes().getRouter());
    router.use('/core/component-templates', new ComponentTemplateRoutes().getRouter());
    router.use('/core/license-manager', new LicenseManagerRoutes().getRouter());
    router.use('/core/logging-service', new LoggingServiceRoutes().getRouter());
    router.use('/core/infrastructure', new InfrastructureManagerRoutes().getRouter());
    router.use('/core/lookups', new LookupsRoutes().getRouter());
    router.use('/core/networks', new NetworkRoutes().getRouter());
    router.use('/designer', new DesignerRoutes().getRouter());
    router.use('/download', new DownloadRoutes().getRouter());

    if (process.env.SERVER_OPEN) {
      router.use('/open/attack-templates', new OpenAttackTemplateRoutes().getRouter());
      router.use('/open/event-templates', new OpenAttackEventRoutes().getRouter());
      router.use('/open/attack-scenarios', new OpenAttackScenarioRoutes().getRouter());
      router.use('/open/traffic-templates', new TrafficTemplateRoutes().getRouter());
      router.use('/open/traffic-profiles', new OpenTrafficProfileRoutes().getRouter());
      router.use('/open/attack-controller', new AttackControllerRoutes().getRouter());
    }
  } catch (err) {
    logger.error(err.message);
  }

  return router;
};

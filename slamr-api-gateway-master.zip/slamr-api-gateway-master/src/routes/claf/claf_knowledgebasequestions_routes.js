import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.CLAF.KNOWLEDGEBASEQUESTIONS.LIST },
  { verb: 'get', route: '/topics', topic: topics.CLAF.KNOWLEDGEBASEQUESTIONS.LIST_TOPICS },
  { verb: 'get', route: '/options', topic: topics.CLAF.KNOWLEDGEBASEQUESTIONS.LIST_OPTIONS },
  { verb: 'post', route: '/options', topic: topics.CLAF.KNOWLEDGEBASEQUESTIONS.CREATE_OPTIONS },
];

export default class CLAFKnowledgeBaseQuestionRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}


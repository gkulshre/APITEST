import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.CLAF.TRAININGOBJECTIVE.LIST },
  { verb: 'get', route: '/:id', topic: topics.CLAF.TRAININGOBJECTIVE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.CLAF.TRAININGOBJECTIVE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.CLAF.TRAININGOBJECTIVE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.CLAF.TRAININGOBJECTIVE.DELETE },
];

export default class CLAFTrainingObjectiveRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}


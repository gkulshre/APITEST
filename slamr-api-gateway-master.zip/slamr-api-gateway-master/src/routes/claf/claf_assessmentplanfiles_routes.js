import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/:id/tasks-oscar', topic: topics.CLAF.ASSESSMENTPLANFILES.LIST_TASKSOSCAR },
  { verb: 'get', route: '/:id', topic: topics.CLAF.ASSESSMENTPLANFILES.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.CLAF.ASSESSMENTPLANFILES.CREATE },
];

export default class CLAFAssessmentPlanFilesRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}


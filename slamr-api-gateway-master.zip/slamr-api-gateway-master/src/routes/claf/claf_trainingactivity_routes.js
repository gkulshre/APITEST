import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/:id', topic: topics.CLAF.TRAININGACTIVITY.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.CLAF.TRAININGACTIVITY.CREATE },
  { verb: 'put', route: '/:id', topic: topics.CLAF.TRAININGACTIVITY.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.CLAF.TRAININGACTIVITY.DELETE },
];

export default class CLAFTrainingActivityRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}


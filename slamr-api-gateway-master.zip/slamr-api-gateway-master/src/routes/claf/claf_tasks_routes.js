import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.CLAF.TASKS.LIST },
  { verb: 'get', route: '/:id', topic: topics.CLAF.TASKS.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.CLAF.TASKS.CREATE },
  { verb: 'put', route: '/:id', topic: topics.CLAF.TASKS.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.CLAF.TASKS.DELETE },
];

export default class CLAFTasksRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}


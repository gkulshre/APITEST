import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/:id', topic: topics.CLAF.TRAININGREQUIREMENT.RETRIEVE },
  { verb: 'get', route: '/:id/tasks', topic: topics.CLAF.TRAININGREQUIREMENT.LIST_TASKS },
  { verb: 'post', route: '/', topic: topics.CLAF.TRAININGREQUIREMENT.CREATE },
  { verb: 'put', route: '/:id', topic: topics.CLAF.TRAININGREQUIREMENT.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.CLAF.TRAININGREQUIREMENT.DELETE },
];

export default class CLAFTrainingRequirementRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

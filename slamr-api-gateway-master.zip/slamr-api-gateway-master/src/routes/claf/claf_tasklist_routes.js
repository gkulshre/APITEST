import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.CLAF.TASKLIST.LIST },
  { verb: 'get', route: '/:id', topic: topics.CLAF.TASKLIST.RETRIEVE },
];

export default class CLAFTaskListRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

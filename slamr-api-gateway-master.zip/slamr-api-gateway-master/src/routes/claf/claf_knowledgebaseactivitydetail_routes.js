import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.CLAF.KNOWLEDGEBASEACTIVITYDETAIL.LIST },
  { verb: 'get', route: '/:id', topic: topics.CLAF.KNOWLEDGEBASEACTIVITYDETAIL.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.CLAF.KNOWLEDGEBASEACTIVITYDETAIL.CREATE },
  { verb: 'put', route: '/:id', topic: topics.CLAF.KNOWLEDGEBASEACTIVITYDETAIL.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.CLAF.KNOWLEDGEBASEACTIVITYDETAIL.DELETE },
];

export default class CLAFKnowledgeBaseActivityDetailRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}


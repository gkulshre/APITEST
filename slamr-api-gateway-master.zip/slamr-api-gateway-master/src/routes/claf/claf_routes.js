import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import CLAFActivitiesRoutes from './claf_activities_routes';
import CLAFActivityTypeRoutes from './claf_activitytype_routes';
import CLAFAssessmentPlanRoutes from './claf_assessmentplan_routes';
import CLAFAssessmentPlanFilesRoutes from './claf_assessmentplanfiles_routes';
import CLAFAssessmentTypeRoutes from './claf_assessmenttype_routes';
import CLAFKnowledgeBaseActivityDetailRoutes from './claf_knowledgebaseactivitydetail_routes';
import CLAFKnowledgeBaseQuestionRoutes from './claf_knowledgebasequestions_routes';
import CLAFPerformanceMeasureRoutes from './claf_performancemeasure_routes';
import CLAFTasksRoutes from './claf_tasks_routes';
import CLAFTaskListRoutes from './claf_tasklist_routes';
import CLAFTopicsRoutes from './claf_topics_routes';
import CLAFTrainingActivityRoutes from './claf_trainingactivity_routes';
import CLAFTrainingObjectiveRoutes from './claf_trainingobjective_routes';
import CLAFTrainingRequirementRoutes from './claf_trainingrequirement_routes';


const routes = [];

export default class CLAFRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/activities', new CLAFActivitiesRoutes().getRouter());
    router.use('/activitytype', new CLAFActivityTypeRoutes().getRouter());
    router.use('/assessmentplan', new CLAFAssessmentPlanRoutes().getRouter());
    router.use('/assessmentplanfiles', new CLAFAssessmentPlanFilesRoutes().getRouter());
    router.use('/assessmenttype', new CLAFAssessmentTypeRoutes().getRouter());
    router.use('/knowledgebaseactivitydetail', new CLAFKnowledgeBaseActivityDetailRoutes().getRouter());
    router.use('/knowledgebasequestion', new CLAFKnowledgeBaseQuestionRoutes().getRouter());
    router.use('/performancemeasure', new CLAFPerformanceMeasureRoutes().getRouter());
    router.use('/tasks', new CLAFTasksRoutes().getRouter());
    router.use('/tasklist', new CLAFTaskListRoutes().getRouter());
    router.use('/topics', new CLAFTopicsRoutes().getRouter());
    router.use('/trainingactivity', new CLAFTrainingActivityRoutes().getRouter());
    router.use('/trainingobjective', new CLAFTrainingObjectiveRoutes().getRouter());
    router.use('/trainingrequirement', new CLAFTrainingRequirementRoutes().getRouter());
    super(router, routes);
  }
}

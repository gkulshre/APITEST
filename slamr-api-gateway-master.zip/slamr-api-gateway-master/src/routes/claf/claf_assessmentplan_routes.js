import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.CLAF.ASSESSMENTPLANS.LIST },
  { verb: 'get', route: '/:id', topic: topics.CLAF.ASSESSMENTPLANS.RETRIEVE },
  { verb: 'get', route: '/:id/trainingrequirements', topic: topics.CLAF.ASSESSMENTPLANS.LIST_TRAININGREQUIREMENTS },
  { verb: 'get', route: '/:id/trainingactivities', topic: topics.CLAF.ASSESSMENTPLANS.LIST_TRAININGACTIVITIES },
  { verb: 'get', route: '/:id/tasks', topic: topics.CLAF.ASSESSMENTPLANS.LIST_PLAN_TASKS },
  { verb: 'post', route: '/', topic: topics.CLAF.ASSESSMENTPLANS.CREATE },
  { verb: 'post', route: '/:id/clone', topic: topics.CLAF.ASSESSMENTPLANS.CREATE_CLONE },
  { verb: 'put', route: '/:id', topic: topics.CLAF.ASSESSMENTPLANS.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.CLAF.ASSESSMENTPLANS.DELETE },
];

export default class CLAFAssessmentPlanRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}


import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.CLAF.PERFORMANCEMEASURE.LIST },
  { verb: 'get', route: '/:id', topic: topics.CLAF.PERFORMANCEMEASURE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.CLAF.PERFORMANCEMEASURE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.CLAF.PERFORMANCEMEASURE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.CLAF.PERFORMANCEMEASURE.DELETE },
];

export default class CLAFPerformanceMeasureRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

const routes = [
  { verb: 'get', route: '/:id', topic: topics.ATTACK_CONTROLLER.RETRIEVESCENARIO },
  { verb: 'post', route: '/:id/start', topic: topics.ATTACK_CONTROLLER.STARTSCENARIO },
  { verb: 'post', route: '/:id/stop', topic: topics.ATTACK_CONTROLLER.STOPSCENARIO },
  { verb: 'post', route: '/:id/pause', topic: topics.ATTACK_CONTROLLER.PAUSESCENARIO },
  { verb: 'post', route: '/:id/resume', topic: topics.ATTACK_CONTROLLER.RESUMESCENARIO },
  { verb: 'post', route: '/:id/add_event', topic: topics.ATTACK_CONTROLLER.ADDEVENT },
];

export default class ControllerScenarioRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import ControllerScenarioRoutes from './controller_scenario_routes';
import ControllerEventRoutes from './controller_event_routes';

/* */

const routes = [];

export default class AttackControllerRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/scenarios', new ControllerScenarioRoutes().getRouter());
    router.use('/events', new ControllerEventRoutes().getRouter());
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

const routes = [
  { verb: 'post', route: '/', topic: topics.ATTACK_CONTROLLER.CREATEEVENT },
  { verb: 'get', route: '/:id', topic: topics.ATTACK_CONTROLLER.RETRIEVEEVENT },
  { verb: 'post', route: '/:id/start', topic: topics.ATTACK_CONTROLLER.STARTEVENT },
  { verb: 'post', route: '/:id/stop', topic: topics.ATTACK_CONTROLLER.STOPEVENT },
];

export default class ControllerEventRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

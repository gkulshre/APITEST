/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

const routes = [
  { verb: 'get', route: '/', topic: topics.IMAGE.LIST },
  { verb: 'get', route: '/:id', topic: topics.IMAGE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.IMAGE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.IMAGE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.IMAGE.DELETE },
  { verb: 'post', route: '/export', topic: topics.IMAGE.EXPORT },
  { verb: 'post', route: '/import', topic: topics.IMAGE.IMPORT },
];

export default class ImageRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

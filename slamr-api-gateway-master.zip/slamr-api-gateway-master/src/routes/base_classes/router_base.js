/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../../util/logger';
import Formatting from '../../util/formatting';

export class RouterBase {
  constructor(router, routes) {
    this.router = router;
    this.routes = routes;
  }

  getRouter() {
    this.routes.forEach(({ verb, route, topic, callback, intercpt }) => {
      this.router[verb](route, (req, res, next) => {
        let source = req.header('x-forwarded-for') || req.connection.remoteAddress || req.ip;
        logger.debug(`Received '${req.originalUrl}' REST message from ${source}`);
        const data = Object.assign(req.params, req.query, req.body);
        data.sub = req.sub;
        console.log(JSON.stringify(data));
        if (intercpt){
          if (verb === 'post'){
            this.intercept_create(req, res, data, topic);
          } else if (verb === 'put'){
            this.intercept_update(req, res, data, topic);
          } else if (verb === 'delete'){
            this.intercept_delete(req, res, data, topic);
          } else {
            logger.warn(`Unknown verb '${verb}'`);
          }
        } else {
          if (callback && typeof callback === 'function') {
            rmqC.PUB.sendOrchSyncRequest(req, res, data, topic, callback, null);
          } else {
            rmqC.PUB.sendSyncRequest(res, data, topic);
          }
        }
      });
    });
    return this.router;
  }


  intercept_create(req, res, data, topic) {
    console.log('thing1');
    throw new Error('intercept Create Not Implemented');
  }

  intercept_update(req, res, data, topic) {
    throw new Error('intercept Update Not Implemented');
  }

  intercept_delete(req, res, data, topic) {
    throw new Error('intercept Delete Not Implemented');
  }

  static sendResponse(msg, res) {
    try {
      res.status(200).send(msg);
      /* logger.debug(`Initial Async Response returned from route: '${msg.fields.routingKey}' with ID of:
            '${msg.properties.correlationId}'`); */
      logger.debug('Returned Orch Sync Result');
    } catch (err) {
      /* logger.debug(`!!!!!!Response returned from route: '${msg.fields.routingKey}' with ID of:
          '${msg.properties.correlationId}' is not in API FORMAT???`); */
      logger.error(err.message);
      RouterBase.send_error(res.res, err.message, 500, null, null);
    }
  }
  static send_error(res, message, status = 500, type = 'Internal Server Error', code = null){
    try {
      if (res.headersSent === false){
        res.status(status).send(Formatting.formatError(code, type, message));
      }
    } catch (err) {
      logger.error(`Unable to send error message:: ${err.message}`);
    }
  }
}

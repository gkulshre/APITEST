/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../../util/logger';

import request from 'request';

export class AuthBase {

  constructor() {
  }

  do_request(options, res){
    request(options, function(error, response, body){
      if (!error && response.statusCode < 300) {
        res.status(response.statusCode).send(body);
      } else {
        logger.error('Persona Service Request Error:  ' + error);
        res.status(response.statusCode).send(error);
      }
    });
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

const express = require('express');
const router = express.Router();

router.get('/', function(req, res){
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify({ status: 'up' }));
});

module.exports = router;

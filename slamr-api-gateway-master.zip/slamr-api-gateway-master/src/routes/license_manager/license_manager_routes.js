/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.LICENSE_MANAGER.LIST },
  { verb: 'get', route: '/:id', topic: topics.LICENSE_MANAGER.RETRIEVE },
  // { verb: 'post', route: '/', topic: topics.LICENSE_MANAGER.CREATE},
  // { verb: 'put', route: '/:id', topic: topics.LICENSE_MANAGER.UPDATE},
  // { verb: 'delete', route: '/:id', topic: topics.LICENSE_MANAGER.DELETE},
  { verb: 'post', route: '/check', topic: topics.LICENSE_MANAGER.CHECK },
  { verb: 'post', route: '/status', topic: topics.LICENSE_MANAGER.STATUS },
  { verb: 'post', route: '/generate', topic: topics.LICENSE_MANAGER.GENERATE },
  { verb: 'post', route: '/import', topic: topics.LICENSE_MANAGER.IMPORT },
  { verb: 'get', route: '/validate/:id', topic: topics.LICENSE_MANAGER.VALIDATE }];

export default class LicenseManagerRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

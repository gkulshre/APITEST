import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.CIF.NETWORKMAPS.LIST },
  { verb: 'get', route: '/:id', topic: topics.CIF.NETWORKMAPS.RETRIEVE },
  { verb: 'put', route: '/:id', topic: topics.CIF.NETWORKMAPS.UPDATE },
  { verb: 'post', route: '/:id', topic: topics.CIF.NETWORKMAPS.CREATE },
];

export default class CIFNetworkMapRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/playbooks', topic: topics.CIF.CAMPAIGNS.LIST_PLAYBOOKS },
  { verb: 'get', route: '/:id/playbooks', topic: topics.CIF.CAMPAIGNS.RETRIEVE_PLAYBOOKS },
];

export default class CIFCampaignRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

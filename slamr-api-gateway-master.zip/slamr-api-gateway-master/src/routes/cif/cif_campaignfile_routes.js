import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/export', topic: topics.CIF.CAMPAIGNFILES.RETRIEVE },
  { verb: 'get', route: '/:id/export', topic: topics.CIF.CAMPAIGNFILES.RETRIEVE },
  { verb: 'post', route: '/import', topic: topics.CIF.CAMPAIGNFILES.CREATE },
];

export default class CIFCampaignFileRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}


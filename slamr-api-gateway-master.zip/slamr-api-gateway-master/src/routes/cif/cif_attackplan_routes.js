import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.CIF.ATTACKPLANS.LIST },
  { verb: 'get', route: '/:id', topic: topics.CIF.ATTACKPLANS.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.CIF.ATTACKPLANS.CREATE },
  { verb: 'put', route: '/:id', topic: topics.CIF.ATTACKPLANS.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.CIF.ATTACKPLANS.DELETE },
];

export default class CIFAttackPlanRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}


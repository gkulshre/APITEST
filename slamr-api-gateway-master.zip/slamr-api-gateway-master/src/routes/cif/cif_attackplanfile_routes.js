import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/:id', topic: topics.CIF.ATTACKPLANFILES.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.CIF.ATTACKPLANFILES.CREATE },
  { verb: 'post', route: '/:id', topic: topics.CIF.ATTACKPLANFILES.CREATE },
];

export default class CIFAttackPlanFileRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}


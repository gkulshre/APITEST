import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.CIF.ACTIONS.LIST },
  { verb: 'get', route: '/:id/command', topic: topics.CIF.ACTIONS.RETRIEVE_COMMAND },
  { verb: 'post', route: '/', topic: topics.CIF.ACTIONS.CREATE },
  { verb: 'put', route: '/:id', topic: topics.CIF.ACTIONS.UPDATE },
  { verb: 'put', route: '/:id/:triggered_by_id', topic: topics.CIF.ACTIONS.UPDATE },
  { verb: 'post', route: '/:id/play', topic: topics.CIF.ACTIONS.PLAY },
  { verb: 'post', route: '/:id/stop', topic: topics.CIF.ACTIONS.STOP },
];

export default class CIFActionRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/patterns', topic: topics.CIF.MITREATTACKS.LIST_PATTERNS },
  { verb: 'get', route: '/:external_id/patterns', topic: topics.CIF.MITREATTACKS.RETRIEVE_PATTERN },
  { verb: 'get', route: '/:kill_chain_name/phases', topic: topics.CIF.MITREATTACKS.LIST_PHASES },
  { verb: 'get', route: '/matrices', topic: topics.CIF.MITREATTACKS.LIST_MATRICES },
  { verb: 'get', route: '/:external_id/matrices', topic: topics.CIF.MITREATTACKS.RETRIEVE_MATRIX },
];

export default class CIFMitreAttackRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

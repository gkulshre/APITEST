import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'post', route: '/:procedure_id', topic: topics.CIF.INJECTS.CREATE },
  { verb: 'put', route: '/:id', topic: topics.CIF.INJECTS.UPDATE },
  { verb: 'post', route: '/', topic: topics.CIF.INJECTS.CREATE },
  { verb: 'post', route: '/:id/play', topic: topics.CIF.INJECTS.PLAY },
  { verb: 'delete', route: '/:id', topic: topics.CIF.INJECTS.DELETE },
];

export default class CIFInjectRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

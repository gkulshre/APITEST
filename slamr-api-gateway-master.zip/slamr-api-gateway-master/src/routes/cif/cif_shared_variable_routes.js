import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/:id', topic: topics.CIF.SHAREDVARIABLES.RETRIEVE },
  { verb: 'get', route: '/:id/action_values', topic: topics.CIF.SHAREDVARIABLES.ACTION_VALUES },
  { verb: 'post', route: '/', topic: topics.CIF.SHAREDVARIABLES.CREATE },
  { verb: 'put', route: '/:id', topic: topics.CIF.SHAREDVARIABLES.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.CIF.SHAREDVARIABLES.DELETE },
];

export default class CIFSharedVariableRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

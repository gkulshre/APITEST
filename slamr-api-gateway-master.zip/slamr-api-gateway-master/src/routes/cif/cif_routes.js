import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import CIFAttackPlanRoutes from './cif_attackplan_routes';
import CIFAttackPlanFilesRoutes from './cif_attackplanfile_routes';
import CIFBluePrintRoutes from './cif_blueprint_routes';
import CIFProcedureRoutes from './cif_procedure_routes';
import CIFInjectListRoutes from './cif_injectlist_routes';
import CIFInjectRoutes from './cif_inject_routes';
import CIFActionRoutes from './cif_action_routes';
import CIFNetworkMapRoutes from './cif_network_map_routes';
import CIFSharedVariableRoutes from './cif_shared_variable_routes';
import CIFHubRoutes from './cif_hub_routes';
import CIFMitreAttackRoutes from './cif_mitreattack_routes';
import CIFMitreAttackFileRoutes from './cif_mitreattackfile_routes';
import CIFCampaignRoutes from './cif_campaign_routes';
import CIFCampaignFileRoutes from './cif_campaignfile_routes';
import CIFLogsRoutes from './cif_logs_routes';

const routes = [];

export default class CIFRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/attackplans', new CIFAttackPlanRoutes().getRouter());
    router.use('/attackplanfiles', new CIFAttackPlanFilesRoutes().getRouter());
    router.use('/blueprints', new CIFBluePrintRoutes().getRouter());
    router.use('/procedures', new CIFProcedureRoutes().getRouter());
    router.use('/injectlists', new CIFInjectListRoutes().getRouter());
    router.use('/injects', new CIFInjectRoutes().getRouter());
    router.use('/actions', new CIFActionRoutes().getRouter());
    router.use('/networkmaps', new CIFNetworkMapRoutes().getRouter());
    router.use('/sharedvariables', new CIFSharedVariableRoutes().getRouter());
    router.use('/hubs', new CIFHubRoutes().getRouter());
    router.use('/mitreattacks', new CIFMitreAttackRoutes().getRouter());
    router.use('/mitreattackfiles', new CIFMitreAttackFileRoutes().getRouter());
    router.use('/campaigns', new CIFCampaignRoutes().getRouter());
    router.use('/campaignfiles', new CIFCampaignFileRoutes().getRouter());
    router.use('/logs', new CIFLogsRoutes().getRouter());
    super(router, routes);
  }
}

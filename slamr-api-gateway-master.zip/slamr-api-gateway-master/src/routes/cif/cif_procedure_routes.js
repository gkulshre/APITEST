import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.CIF.PROCEDURES.LIST },
  { verb: 'get', route: '/:id', topic: topics.CIF.PROCEDURES.RETRIEVE },
];

export default class CIFProcedureRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

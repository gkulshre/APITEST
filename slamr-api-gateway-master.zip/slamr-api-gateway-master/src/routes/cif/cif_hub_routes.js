import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'put', route: '/:id', topic: topics.CIF.HUBS.UPDATE },
];

export default class CIFHubRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

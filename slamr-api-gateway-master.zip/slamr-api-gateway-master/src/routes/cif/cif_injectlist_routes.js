import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.CIF.INJECTLISTS.LIST },
  { verb: 'get', route: '/:id', topic: topics.CIF.INJECTLISTS.RETRIEVE },
  { verb: 'get', route: '/:id/steam', topic: topics.CIF.INJECTLISTS.STEAM },
  { verb: 'post', route: '/', topic: topics.CIF.INJECTLISTS.CREATE },
  { verb: 'put', route: '/:id', topic: topics.CIF.INJECTLISTS.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.CIF.INJECTLISTS.DELETE },
  { verb: 'post', route: '/:id/play', topic: topics.CIF.INJECTLISTS.PLAY },
  { verb: 'post', route: '/:id/skip', topic: topics.CIF.INJECTLISTS.SKIP },
  { verb: 'post', route: '/:id/stop', topic: topics.CIF.INJECTLISTS.STOP },
];

export default class CIFInjectListRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

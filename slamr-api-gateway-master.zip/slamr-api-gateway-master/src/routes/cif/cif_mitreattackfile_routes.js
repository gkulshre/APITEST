import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/export', topic: topics.CIF.MITREATTACKFILES.RETRIEVE },
  { verb: 'post', route: '/import', topic: topics.CIF.MITREATTACKFILES.CREATE },
];

export default class CIFMitreAttackFileRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}


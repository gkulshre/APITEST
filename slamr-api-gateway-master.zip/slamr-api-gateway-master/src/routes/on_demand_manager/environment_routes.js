/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

const routes = [
  { verb: 'post', route: '/', topic: topics.ON_DEMAND.CREATE },
  { verb: 'put', route: '/:id', topic: topics.ON_DEMAND.UPDATE },
  { verb: 'post', route: '/:id/start', topic: topics.ON_DEMAND.START },
];

export default class DeviceTemplateRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';

/* */

import EnvironmentRoutes from './environment_routes';

const routes = [];

export default class OnDemandRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/environments', new EnvironmentRoutes().getRouter());
    super(router, routes);
  }
}

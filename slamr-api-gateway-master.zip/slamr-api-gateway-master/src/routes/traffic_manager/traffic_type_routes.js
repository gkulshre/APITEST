/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.TRAFFICMANAGER.LISTPROFILETRAFFICTYPES },
  { verb: 'get', route: '/:id', topic: topics.TRAFFICMANAGER.RETRIEVEPROFILETRAFFTYPE },
  { verb: 'post', route: '/', topic: topics.TRAFFICMANAGER.CREATEPROFILETRAFFTYPE },
  { verb: 'put', route: '/:id', topic: topics.TRAFFICMANAGER.UPDATEPROFILETRAFFTYPE },
  { verb: 'delete', route: '/:id', topic: topics.TRAFFICMANAGER.DELETEPROFILETRAFFTYPE },
];

export default class TrafficTypeRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

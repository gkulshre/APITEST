/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { Router } from 'express';
import topics from '../topics';
import { RouterBase } from '../base_classes/router_base';
import TrafficTypeRoutes from '../traffic_manager/traffic_type_routes';

const routes = [
  { verb: 'get', route: '/', topic: topics.TRAFFICMANAGER.LISTPROFBYDOM },
  { verb: 'get', route: '/:id', topic: topics.TRAFFICMANAGER.RETRIEVEPROFILE },
  { verb: 'post', route: '/', topic: topics.TRAFFICMANAGER.CREATEPROFILE },
  { verb: 'put', route: '/:id', topic: topics.TRAFFICMANAGER.UPDATEPROFILE },
  { verb: 'delete', route: '/:id', topic: topics.TRAFFICMANAGER.DELETEPROFILE },
];

export default class OpenTrafficProfileRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/:profile_id/traffic_types', new TrafficTypeRoutes().getRouter());
    super(router, routes);
  }
}

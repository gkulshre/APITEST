/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.LOOKUPS.AD_ACCOUNT_TYPE.LIST },
  { verb: 'get', route: '/:id', topic: topics.LOOKUPS.AD_ACCOUNT_TYPE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.LOOKUPS.AD_ACCOUNT_TYPE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.LOOKUPS.AD_ACCOUNT_TYPE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.LOOKUPS.AD_ACCOUNT_TYPE.DELETE },
  { verb: 'post', route: '/import', topic: topics.LOOKUPS.AD_ACCOUNT_TYPE.IMPORT }];

export default class AdAccountTypeRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

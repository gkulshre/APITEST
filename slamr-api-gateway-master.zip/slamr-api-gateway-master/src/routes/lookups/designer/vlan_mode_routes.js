/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.LOOKUPS.VLAN_MODE.LIST },
  { verb: 'get', route: '/:id', topic: topics.LOOKUPS.VLAN_MODE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.LOOKUPS.VLAN_MODE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.LOOKUPS.VLAN_MODE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.LOOKUPS.VLAN_MODE.DELETE },
  { verb: 'post', route: '/import', topic: topics.LOOKUPS.VLAN_MODE.IMPORT }];

export default class VlanModeRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

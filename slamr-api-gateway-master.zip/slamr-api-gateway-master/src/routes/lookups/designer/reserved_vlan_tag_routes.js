/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.LOOKUPS.RESERVEDVLANTAG.LIST },
  { verb: 'get', route: '/:id', topic: topics.LOOKUPS.RESERVEDVLANTAG.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.LOOKUPS.RESERVEDVLANTAG.CREATE },
  { verb: 'put', route: '/:id', topic: topics.LOOKUPS.RESERVEDVLANTAG.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.LOOKUPS.RESERVEDVLANTAG.DELETE }];

export default class ReservedVlanTagRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

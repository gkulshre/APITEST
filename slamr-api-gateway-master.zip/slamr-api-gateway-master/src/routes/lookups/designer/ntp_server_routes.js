/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.LOOKUPS.NTP_SERVER.LIST },
  { verb: 'get', route: '/:id', topic: topics.LOOKUPS.NTP_SERVER.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.LOOKUPS.NTP_SERVER.CREATE },
  { verb: 'put', route: '/:id', topic: topics.LOOKUPS.NTP_SERVER.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.LOOKUPS.NTP_SERVER.DELETE },
  { verb: 'post', route: '/import', topic: topics.LOOKUPS.NTP_SERVER.IMPORT }];

export default class NtpServerRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.LOOKUPS.SLAMR_INTERNET_SITE.LIST },
  { verb: 'get', route: '/:id', topic: topics.LOOKUPS.SLAMR_INTERNET_SITE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.LOOKUPS.SLAMR_INTERNET_SITE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.LOOKUPS.SLAMR_INTERNET_SITE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.LOOKUPS.SLAMR_INTERNET_SITE.DELETE },
  { verb: 'post', route: '/import', topic: topics.LOOKUPS.SLAMR_INTERNET_SITE.IMPORT }];

export default class SlamrInternetSiteRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

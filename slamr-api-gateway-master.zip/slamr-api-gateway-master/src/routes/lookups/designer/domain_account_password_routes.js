/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.LOOKUPS.DOMAIN_ACCOUNT_PASSWORD.LIST },
  { verb: 'get', route: '/:id', topic: topics.LOOKUPS.DOMAIN_ACCOUNT_PASSWORD.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.LOOKUPS.DOMAIN_ACCOUNT_PASSWORD.CREATE },
  { verb: 'put', route: '/:id', topic: topics.LOOKUPS.DOMAIN_ACCOUNT_PASSWORD.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.LOOKUPS.DOMAIN_ACCOUNT_PASSWORD.DELETE },
  { verb: 'post', route: '/import', topic: topics.LOOKUPS.DOMAIN_ACCOUNT_PASSWORD.IMPORT }];

export default class DomainAccountPasswordRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

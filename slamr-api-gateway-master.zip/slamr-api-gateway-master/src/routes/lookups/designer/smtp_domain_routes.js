/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.LOOKUPS.SMTP_DOMAIN.LIST },
  { verb: 'get', route: '/:id', topic: topics.LOOKUPS.SMTP_DOMAIN.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.LOOKUPS.SMTP_DOMAIN.CREATE },
  { verb: 'put', route: '/:id', topic: topics.LOOKUPS.SMTP_DOMAIN.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.LOOKUPS.SMTP_DOMAIN.DELETE },
  { verb: 'post', route: '/import', topic: topics.LOOKUPS.SMTP_DOMAIN.IMPORT }];

export default class SmtpDomainRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

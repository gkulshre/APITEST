/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

const routes = [
  { verb: 'get', route: '/', topic: topics.LOOKUPS.NETMAPS.LIST },
  { verb: 'get', route: '/:id', topic: topics.LOOKUPS.NETMAPS.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.LOOKUPS.NETMAPS.CREATE },
  { verb: 'put', route: '/:id', topic: topics.LOOKUPS.NETMAPS.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.LOOKUPS.NETMAPS.DELETE },
  { verb: 'post', route: '/import', topic: topics.LOOKUPS.NETMAPS.IMPORT },
];

export default class NetmapRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

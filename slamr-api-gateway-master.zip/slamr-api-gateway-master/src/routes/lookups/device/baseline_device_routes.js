/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.LOOKUPS.BASELINEDEVICETEMPLATES.LIST },
  { verb: 'get', route: '/:id', topic: topics.LOOKUPS.BASELINEDEVICETEMPLATES.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.LOOKUPS.BASELINEDEVICETEMPLATES.CREATE },
  { verb: 'put', route: '/:id', topic: topics.LOOKUPS.BASELINEDEVICETEMPLATES.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.LOOKUPS.BASELINEDEVICETEMPLATES.DELETE }];

export default class BaselineDeviceRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

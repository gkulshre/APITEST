/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.LOOKUPS.VIDEODRIVER.LIST },
  { verb: 'get', route: '/:id', topic: topics.LOOKUPS.VIDEODRIVER.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.LOOKUPS.VIDEODRIVER.CREATE },
  { verb: 'put', route: '/:id', topic: topics.LOOKUPS.VIDEODRIVER.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.LOOKUPS.VIDEODRIVER.DELETE }];

export default class VideoDriverRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

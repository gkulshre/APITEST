/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.LOOKUPS.ARCHITECTURE.LIST },
  { verb: 'get', route: '/:id', topic: topics.LOOKUPS.ARCHITECTURE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.LOOKUPS.ARCHITECTURE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.LOOKUPS.ARCHITECTURE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.LOOKUPS.ARCHITECTURE.DELETE }];

export default class ArchitectureRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.LOOKUPS.OSFLAVOR.LIST },
  { verb: 'get', route: '/:id', topic: topics.LOOKUPS.OSFLAVOR.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.LOOKUPS.OSFLAVOR.CREATE },
  { verb: 'put', route: '/:id', topic: topics.LOOKUPS.OSFLAVOR.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.LOOKUPS.OSFLAVOR.DELETE }];

export default class OsFlavorRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.LOOKUPS.KERNELTYPE.LIST },
  { verb: 'get', route: '/:id', topic: topics.LOOKUPS.KERNELTYPE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.LOOKUPS.KERNELTYPE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.LOOKUPS.KERNELTYPE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.LOOKUPS.KERNELTYPE.DELETE }];

export default class KernelTypeRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

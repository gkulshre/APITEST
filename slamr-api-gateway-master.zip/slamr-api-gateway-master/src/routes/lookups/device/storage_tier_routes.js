/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.LOOKUPS.STORAGETIER.LIST },
  { verb: 'get', route: '/:id', topic: topics.LOOKUPS.STORAGETIER.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.LOOKUPS.STORAGETIER.CREATE },
  { verb: 'put', route: '/:id', topic: topics.LOOKUPS.STORAGETIER.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.LOOKUPS.STORAGETIER.DELETE }];

export default class StorageTierRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

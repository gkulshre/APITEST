/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.LOOKUPS.CPUALLOCATIONTYPE.LIST },
  { verb: 'get', route: '/:id', topic: topics.LOOKUPS.CPUALLOCATIONTYPE.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.LOOKUPS.CPUALLOCATIONTYPE.CREATE },
  { verb: 'put', route: '/:id', topic: topics.LOOKUPS.CPUALLOCATIONTYPE.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.LOOKUPS.CPUALLOCATIONTYPE.DELETE }];

export default class CpuAllocationTypeRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

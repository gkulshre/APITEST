/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';

import NodeDeviceRoutes from '../device_manager/node_device_routes';
import AttackModuleRoutes from '../attack_template/attack_module_routes';
import AttackPayloadRoutes from '../attack_template/attack_payload_routes';
import DMTypeRoutes from './dmtype_routes';
import NetmapRoutes from './netmap_routes';
import TrafficProfileTemplateRoutes from '../traffic_manager/traffic_profile_template_routes';
import TrafficTypeTemplateRoutes from '../traffic_manager/traffic_type_template_routes';
import CentsEventTemplateRoutes from '../attack_template/cents_event_template_routes';

import BaselineDeviceRoutes from './device/baseline_device_routes';
import BusTypeRoutes from './device/bus_type_routes';
import ConnectionTypeRoutes from './device/connection_type_routes';
import CpuAllocationTypeRoutes from './device/cpu_allocation_type_routes';
import CpuTypeRoutes from './device/cpu_type_routes';
import GraphicTypeRoutes from './device/graphic_type_routes';
import MemorySizeRoutes from './device/memory_size_routes';
import NicModelRoutes from './device/nic_model_routes';
import StorageFormatRoutes from './device/storage_format_routes';
import StorageTierRoutes from './device/storage_tier_routes';
import VideoDriverRoutes from './device/video_driver_routes';
import ArchitectureRoutes from './device/architecture_routes';
import FileSystemTypeRoutes from './device/file_system_type_routes';
import KernelTypeRoutes from './device/kernel_type_routes';
import OsFlavorRoutes from './device/os_flavor_routes';
import ImageSourceRoutes from './device/image_source_routes';
import InfrastructureManagerRoutes from '../infrastructure_manager/infrastructure_manager_routes';

import AdAccountTypeRoutes from './designer/ad_account_type_routes';
import BondModeRoutes from './designer/bond_mode_routes';
import BridgeTypeRoutes from './designer/bridge_type_routes';
import DomainAccountPasswordRoutes from './designer/domain_account_password_routes';
import DomainTypeRoutes from './designer/domain_type_routes';
import LacpModeRoutes from './designer/lacp_mode_routes';
import LocalCredentialRoutes from './designer/local_credential_routes';
import NodeTypeRoutes from './designer/node_type_routes';
import NtpServerRoutes from './designer/ntp_server_routes';
import PortTypeRoutes from './designer/port_type_routes';
import ProjectTypeRoutes from './designer/project_type_routes';
import SlamrSiteRoutes from './designer/slamr_internet_site_routes';
import SmtpDomainRoutes from './designer/smtp_domain_routes';
import SystemTypeRoutes from './designer/system_type_routes';
import VlanModeRoutes from './designer/vlan_mode_routes';
import ObjectTypeRoutes from './designer/object_type_routes';
import ObjectSubTypeRoutes from './designer/object_type_subtype_routes';
import ReservedVlanTagRoutes from './designer/reserved_vlan_tag_routes';

import ServiceTypeRoutes from './designer/service_type_routes';

const routes = [];

export default class LookupsRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    router.use('/baseline-devices', new BaselineDeviceRoutes().getRouter());
    router.use('/storage-drivers', new BusTypeRoutes().getRouter());
    router.use('/connection-types', new ConnectionTypeRoutes().getRouter());
    router.use('/cpu-allocation-types', new CpuAllocationTypeRoutes().getRouter());
    router.use('/cpu-types', new CpuTypeRoutes().getRouter());
    router.use('/graphic-types', new GraphicTypeRoutes().getRouter());
    router.use('/memory-sizes', new MemorySizeRoutes().getRouter());
    router.use('/network-drivers', new NicModelRoutes().getRouter());
    router.use('/storage-formats', new StorageFormatRoutes().getRouter());
    router.use('/storage-tiers', new StorageTierRoutes().getRouter());
    router.use('/video-drivers', new VideoDriverRoutes().getRouter());
    router.use('/architectures', new ArchitectureRoutes().getRouter());
    router.use('/file-systems', new FileSystemTypeRoutes().getRouter());
    router.use('/kernel-types', new KernelTypeRoutes().getRouter());
    router.use('/os-flavors', new OsFlavorRoutes().getRouter());
    router.use('/attack-modules', new AttackModuleRoutes().getRouter());
    router.use('/attack-payloads', new AttackPayloadRoutes().getRouter());
    router.use('/cents-attack-templates', new CentsEventTemplateRoutes().getRouter());
    router.use('/traffic-profile-templates', new TrafficProfileTemplateRoutes().getRouter());
    router.use('/traffic-type-templates', new TrafficTypeTemplateRoutes().getRouter());
    router.use('/image-sources', new ImageSourceRoutes().getRouter());
    router.use('/dmtypes', new DMTypeRoutes().getRouter());
    router.use('/netmaps', new NetmapRoutes().getRouter());
    router.use('/infra-manager', new InfrastructureManagerRoutes().getRouter());
    router.use('/ad-account-types', new AdAccountTypeRoutes().getRouter());
    router.use('/bond-modes', new BondModeRoutes().getRouter());
    router.use('/domain-account-passwords', new DomainAccountPasswordRoutes().getRouter());
    router.use('/lacp-modes', new LacpModeRoutes().getRouter());
    router.use('/local-credentials', new LocalCredentialRoutes().getRouter());
    router.use('/node-types', new NodeTypeRoutes().getRouter());
    router.use('/ntp-servers', new NtpServerRoutes().getRouter());
    router.use('/port-types', new PortTypeRoutes().getRouter());
    router.use('/project-types', new ProjectTypeRoutes().getRouter());
    router.use('/slamr-sites', new SlamrSiteRoutes().getRouter());
    router.use('/smtp-domains', new SmtpDomainRoutes().getRouter());
    router.use('/system-types', new SystemTypeRoutes().getRouter());
    router.use('/vlan-modes', new VlanModeRoutes().getRouter());
    router.use('/domain-types', new DomainTypeRoutes().getRouter());
    router.use('/object-types', new ObjectTypeRoutes().getRouter());
    router.use('/object-sub-types', new ObjectSubTypeRoutes().getRouter());
    router.use('/bridge_types', new BridgeTypeRoutes().getRouter());
    router.use('/reserved_vlan_tags', new ReservedVlanTagRoutes().getRouter());
    router.use('/services-types', new ServiceTypeRoutes().getRouter());

    // tmp routes

    router.use('/device-nodes', new NodeDeviceRoutes().getRouter());

    super(router, routes);
  }
}

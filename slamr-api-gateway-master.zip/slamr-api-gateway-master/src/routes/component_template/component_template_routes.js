/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import ComponentRoutes from './component_routes';
import DeviceTemplateRoutes from './device_template_routes';
import DeviceTemplateSubroutes from './device_template_subroutes';

const routes = [];

export default class ComponentTemplateRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    router.use('/components', new ComponentRoutes().getRouter());
    router.use('/device-templates', new DeviceTemplateRoutes().getRouter());
    router.use('/:componentId/device-templates', new DeviceTemplateSubroutes().getRouter());
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

const routes = [
  { verb: 'get', route: '/:id/link', topic: topics.COMPONENT_TEMPLATE.DEVICE_TEMPLATE.LINK },
  { verb: 'get', route: '/:id/unlink', topic: topics.COMPONENT_TEMPLATE.DEVICE_TEMPLATE.UNLINK },
];

export default class DeviceTemplateSubroutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.COMPONENT_TEMPLATE.COMPONENT.LIST },
  { verb: 'get', route: '/upload_precheck', topic: topics.COMPONENT_TEMPLATE.COMPONENT.UPLOAD_PRECHECK },
  { verb: 'get', route: '/:id', topic: topics.COMPONENT_TEMPLATE.COMPONENT.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.COMPONENT_TEMPLATE.COMPONENT.CREATE },
  { verb: 'put', route: '/:id', topic: topics.COMPONENT_TEMPLATE.COMPONENT.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.COMPONENT_TEMPLATE.COMPONENT.DELETE },
];

export default class ComponentRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

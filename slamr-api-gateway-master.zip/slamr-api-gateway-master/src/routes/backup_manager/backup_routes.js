/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
/* */

const routes = [
  { verb: 'post', route: '/config', topic: topics.BACKUP.CONFIG },
  { verb: 'get', route: '/services', topic: topics.BACKUP.SERVICE_LIST },
  { verb: 'post', route: '/', topic: topics.BACKUP.CREATE },
  { verb: 'get', route: '/restore', topic: topics.BACKUP.RESTORE_LIST },
  { verb: 'post', route: '/restore/:id', topic: topics.BACKUP.RESTORE },
  { verb: 'get', route: '/', topic: topics.BACKUP.LIST },
  { verb: 'get', route: '/:id', topic: topics.BACKUP.MANIFEST },
  { verb: 'delete', route: '/:id', topic: topics.BACKUP.DESTROY },
];

export default class BackupRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

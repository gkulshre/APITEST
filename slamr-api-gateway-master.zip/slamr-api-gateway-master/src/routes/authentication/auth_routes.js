/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';
import AccountRoutes from './account_routes';
import PolicyRoutes from './policy_routes';
import RoleRoutes from './role_routes';
import ControlRoutes from './control_routes';
import PComplexRoutes from './complexity_routes';
import AuditRoutes from './audit_routes';

const routes = [
  { verb: 'post', route: '/', topic: topics.AUTHENTICATION.AUTHENTICATE }];

export default class DomainDeviceRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    router.use('/accounts', new AccountRoutes().getRouter());
    router.use('/policies', new PolicyRoutes().getRouter());
    router.use('/roles', new RoleRoutes().getRouter());
    router.use('/controls', new ControlRoutes().getRouter());
    router.use('/passcomplexities', new PComplexRoutes().getRouter());
    router.use('/audits', new AuditRoutes().getRouter());

    super(router, routes);
  }
}

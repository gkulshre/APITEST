/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.ROLES.LIST },
  { verb: 'get', route: '/:id', topic: topics.ROLES.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.ROLES.CREATE },
  { verb: 'put', route: '/:id', topic: topics.ROLES.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.ROLES.DELETE },
  { verb: 'post', route: '/:role_id/add-user', topic: topics.ROLES.ADDUSER },
  { verb: 'post', route: '/:role_id/remove-user', topic: topics.ROLES.REMOVEUSER },
  { verb: 'post', route: '/:role_id/enable-policy-action', topic: topics.ROLES.ENABLEPOLICY },
  { verb: 'post', route: '/:role_id/disable-policy-action', topic: topics.ROLES.DISABLEPOLICY }];

export default class RoleRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import topics from '../topics';

const routes = [
  { verb: 'get', route: '/', topic: topics.ACCOUNTS.LIST },
  { verb: 'get', route: '/:id', topic: topics.ACCOUNTS.RETRIEVE },
  { verb: 'post', route: '/', topic: topics.ACCOUNTS.CREATE },
  { verb: 'put', route: '/:id', topic: topics.ACCOUNTS.UPDATE },
  { verb: 'delete', route: '/:id', topic: topics.ACCOUNTS.DELETE },
  { verb: 'post', route: '/:id/change-password', topic: topics.ACCOUNTS.CHANGEPASSWORD },
  { verb: 'post', route: '/reset-password', topic: topics.ACCOUNTS.RESETPASSWORD }];

export default class AccountRoutes extends RouterBase {
  constructor() {
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

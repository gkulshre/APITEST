/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import topics from '../../topics';


const routes = [
  { verb: 'post', route: '/', topic: topics.LOGGINGSERVICE.PURGECOMMAND },
];

export default class LoggingServicePurgeCommand extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import LoggingServicePurgeCommand from './logging_service_purge_command';
import LoggingServiceExportCommand from './logging_service_export_command';
import LoggingServiceExportAllCommand from './logging_service_export_all_command';
import LoggingServiceChangeLogCommand from './logging_service_change_log_command';


const routes = [];

export default class LoggingServiceCommandRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    router.use('/purge', new LoggingServicePurgeCommand().getRouter());
    router.use('/export', new LoggingServiceExportCommand().getRouter());
    router.use('/export-all', new LoggingServiceExportAllCommand().getRouter());
    router.use('/change-level', new LoggingServiceChangeLogCommand().getRouter());
    super(router, routes);
  }
}

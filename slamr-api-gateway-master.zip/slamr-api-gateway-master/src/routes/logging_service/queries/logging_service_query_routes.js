/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../../base_classes/router_base';
import { Router } from 'express';
import LoggingServiceLogRoutes from './logging_service_log_routes';
import LoggingServiceRetentionRoutes from './logging_service_retention_routes';


const routes = [];

export default class LoggingServiceCommandRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    router.use('/logs', new LoggingServiceLogRoutes().getRouter());
    router.use('/retention', new LoggingServiceRetentionRoutes().getRouter());
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import { RouterBase } from '../base_classes/router_base';
import { Router } from 'express';
import LoggingServiceCommandRoutes from './commands/logging_service_command_routes';
import LoggingServiceLookupRoutes from './lookups/logging_service_lookup_routes';
import LoggingServiceQueryRoutes from './queries/logging_service_query_routes';


const routes = [];

export default class SystemDesignerRoutes extends RouterBase {
  constructor(){
    const router = new Router({ mergeParams: true });
    router.use('/lookups', new LoggingServiceLookupRoutes().getRouter());
    router.use('/queries', new LoggingServiceQueryRoutes().getRouter());
    router.use('/commands', new LoggingServiceCommandRoutes().getRouter());
    super(router, routes);
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import RoleMapper from './role_mapper';
import DomainMapper from './domain_mapper';

export default class MatrixController {
  constructor() {
    this.rm = new RoleMapper();
    this.dm = new DomainMapper();
    this.cnt = 0;
    this.ready = false;
    this.roles_ready = false;
  }

  sleep(milliseconds) {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  };

  async buildMatrix(){
    try {

      logger.debug('Attempting to map roles....');
      await this.rm.mapRoles();
      logger.debug('Mapped Roles....');
      // logger.debug('Attempting to map Domains....');
      // this.dm.mapDomains();

    } catch (err) {
      logger.error(err.message);
      if (!security.matrix.ready) {
        await this.sleep(process.env.MATRIX_RETRY_INTERVAL).then(() => {
          this.cnt++;
          logger.info('Attempting to build matrix again after failure');
          if (this.cnt <= process.env.MATRIX_RETRY_ATTEMPTS) {
            this.buildMatrix();
          } else {
            logger.error('Max Retry reached.  Stopping trying to build matrix map.');
            process.exit(1);
          }
        });
      }
    }
  }

  start(cb){
    logger.info('Matrix Mapping Started...');

    this.buildMatrix()
      .catch((err) => {
        logger.error(err.message);
      });
    if (cb) { cb(); }
  }
}

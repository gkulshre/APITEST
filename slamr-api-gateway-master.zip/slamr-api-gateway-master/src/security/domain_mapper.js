/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import UUID from 'uuid/v4';

const domainRoute = '*.domain.manager.*.list.domain.request';

export default class DomainMapper {
  constructor(){
  }

  mapDomains() {
    this.getDomainInfo();
    this.cnt = 0;
  }

  parseResult(data) {
    security.matrix.domains = [];
    security.matrix.domainReads = [];
    let jdata = JSON.parse(data);
    if (Array.isArray(jdata.data)){
      jdata.data.map((d) => {
        let tmpO = {};
        tmpO.domain = d.id;
        // Get list of roles for each domain with at least read capability
        let a = new Set(d.roles); let b = new Set(security.matrix.policyDomainRead);
        tmpO.reads = [...a].filter(v => b.has(v));
        logger.debug('reads>>' + tmpO.reads);
        logger.debug('domain>>' + d.id);
        security.matrix.domainReads.push(tmpO);
        security.matrix.domains.push(d.id);
      });
      security.matrix.ready = true;
      this.cnt = 0;

      logger.debug('Domains Mapped....');
      logger.debug('Matrix Mapping Completed');

    } else {
      logger.error(`Invalid domain response ${jdata}`);
    }
  }


  sleep(milliseconds) {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  };

  async retryDomainInfo(){
    await this.sleep(process.env.MATRIX_RETRY_INTERVAL).then(() => {
      this.cnt++;
      logger.info('Attempting to get domain info again');
      if (this.cnt <= process.env.MATRIX_RETRY_ATTEMPTS) {
        if (!security.matrix.ready){
          logger.debug('Calling get domain again::' + this.cnt + '::' + security.matrix.ready + '<<<');
          this.getDomainInfo();
        }
      } else {
        logger.error('Max Retry reached.  Stopping trying to get domains and build matrix map.');
        process.exit(1);
      }
    });
  }

  getDomainInfo(){

    let uid = UUID();
    let data = {};

    let options = {
      correlationId: uid,
      replyTo: process.env.RABBITMQ_MATRIX_RESP_ROUTE,
      expiration: 1000,
    };
    /* eslint-disable new-cap */
    rmqC.channel.publish(process.env.RABBITMQ_EXCH, domainRoute, new Buffer.from(JSON.stringify(data)), options);
    /* eslint-enable new-cap */
    this.retryDomainInfo();
  }
}

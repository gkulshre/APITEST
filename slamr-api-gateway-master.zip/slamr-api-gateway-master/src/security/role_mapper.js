/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import UUID from 'uuid/v4';

const roleRoute = '*.authentication.service.*.listread.role.request';

export default class RoleMapper {
  constructor(){
    this.rcnt = 0;
  }

  parseResult(data) {
    logger.debug('Parsing Roles');
    security.matrix.roles = [];
    security.matrix.policyDomainRead = [];
    let jdata = JSON.parse(data);
    if (Array.isArray(jdata.data)){
      jdata.data.map((d) => {
        d.read_roles.map((rr) => {
          security.matrix.policyDomainRead.push(rr);
        });
        d.roles.map((r) => {
          security.matrix.roles.push(r);
        });
      });
    }
    security.matrix.roles_ready = true;
    logger.debug('Read Roles Mapped....');
    logger.debug('Attempting to Map Domains....');
    this.rcnt = 0;

    security.matrix.dm.mapDomains();
  }


  mapRoles() {
    this.doMapRoles();
    this.rcnt = 0;
  }

  doMapRoles(){
    logger.debug('Role Mapping Called');

    let uid = UUID();
    let data = {};
    data.domain_policy_id = process.env.POLICIES_DOMAIN;

    let options = {
      correlationId: uid,
      replyTo: process.env.RABBITMQ_MATRIX_ROLE_RESP_QUEUE,
      expiration: 500,
    };
    /* eslint-disable new-cap */
    rmqC.channel.publish(process.env.RABBITMQ_EXCH, roleRoute, new Buffer.from(JSON.stringify(data)), options);
    /* eslint-enable new-cap */
    this.retryMapRoles();
  }

  sleep(milliseconds) {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  };

  async retryMapRoles(){
    await this.sleep(process.env.MATRIX_RETRY_INTERVAL).then(() => {
      this.rcnt++;
      logger.info('Attempting to get role info again');
      if (this.rcnt <= process.env.MATRIX_RETRY_ATTEMPTS) {
        if (!security.matrix.roles_ready){
          this.doMapRoles();
        }
      } else {
        logger.error('Max Retry reached.  Stopping trying to get roles and build matrix map.');
        process.exit(1);
      }
    });
  }
}

/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import UUID from 'uuid/v4';

export default class LicenseController {
  constructor() {
    this.products = [];
    this.products_detail = [];
  }

  start(){
    logger.info('Starting License Request');
    this.getLicense();
  }

  parseLicenses(data){
    logger.info('Parsing License Info');
    let jdata = JSON.parse(data);
    if (Array.isArray(jdata.data)){
      let pdata = jdata.data[0];
      if (Array.isArray(pdata)) {
        pdata.forEach(packs => {
          let dte = new Date();
          let pdte = Date.parse(packs.expires);
          if (pdte < dte){
            let pproducts = packs.products;
            if (Array.isArray(pproducts)){
              pproducts.forEach(product => {
                if (security.license.products.indexOf(product.id) === -1){
                  security.license.products.push(product.id);
                  security.license.products_detail.push(product);
                } else {
                  security.license.products_detail.forEach(item => {
                    if (item.id === product.id){
                      item.count = item.count + product.count;
                    }
                  });
                }
              });
              logger.debug(`Products Added:  ${security.license.products}`);
            } else {
              logger.error(`Invalid License response.  Missing Products:  ${jdata}`);
              security.license.products = [];
              security.license.products_detail = [];
            }
          }
        });
      } else {
        logger.error(`Invalid License response.  Missing Packs:  ${jdata}`);
        security.license.products = [];
        security.license.products_detail = [];
      }
    } else {
      logger.error(`Invalid License response:  ${jdata}`);
      security.license.products = [];
      security.license.products_detail = [];
    }
  };

  getLicense(){
    logger.debug('License Being Requested');

    let uid = UUID();
    let data = {};

    let options = {
      correlationId: uid,
      replyTo: process.env.RABBITMQ_LICENSE_LISTENER_QUEUE,
      expiration: 500,
    };
    /* eslint-disable new-cap */
    rmqC.channel.publish(process.env.RABBITMQ_EXCH, '*.license.manager.*.list.license.request', new Buffer.from(JSON.stringify(data)), options);
  };
}

#!/bin/bash

# Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved


mkdir -p /opt/slamr
rm -rf /opt/slamr/slamr-api-gateway

cp -R $PWD/build /opt/slamr/slamr-api-gateway
systemctl enable /opt/slamr/slamr-api-gateway/systemd/slamr-api-gateway-test.service
systemctl daemon-reload
systemctl restart slamr-api-gateway-test

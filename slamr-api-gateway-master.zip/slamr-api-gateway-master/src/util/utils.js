/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import fs from 'fs-extra';


export const SourceTypes = {
  DOMAIN: 0,
  DEVICE: 1,
  NETWORK: 2,
  ATTACK: 3,
  TRAFFIC: 4,
  INFRASTRUCTURE: 5,
  CIF: 6,
  CLAF: 7,
  PROJECT: 8,
  ERROR: 9,
  UNK: 10,
  IMAGE: 11,
};

/**
 * Utility class for standard operations.
 */
export default class Utils {

  /**
     * Helper method for creating paths recursively.
     * @param {string} path - The path to create.
     * @returns {undefined} - Should not return anything.
     */
  static createPath(path) {
    if (!this.pathExists(path)) { fs.ensureDirSync(path); }
  }

  /**
     * Helper method to check if a path exists
     * @param {string} path - The patch to check.
     * @returns {boolean} - Returns true if the path exists.
     */
  static pathExists(path) {
    return fs.existsSync(path);
  }

  static getSourceFromKey(route) {
    let result = SourceTypes.UNK;
    console.log('Case Routes:  ' + route);
    // eslint-disable-next-line max-len
    if (route.includes('.device')){ result = SourceTypes.DEVICE; } else if (route.includes('.vd')){ result = SourceTypes.DEVICE; } else if (route.includes('cif.service')){ result = SourceTypes.CIF; } else if (route.includes('claf.service')) { result = SourceTypes.CLAF; } else if (route.includes('project.')) { result = SourceTypes.PROJECT; } else if (route.includes('.domain')){ result = SourceTypes.DOMAIN; } else if (route.includes('.network')){ result = SourceTypes.NETWORK; } else if (route.includes('.attack.manager')){ result = SourceTypes.ATTACK; } else if (route.includes('.traffic.manager')){ result = SourceTypes.TRAFFIC; } else if (route.includes('.vn')){ result = SourceTypes.NETWORK; } else if (route.includes('sim.manager')){
      if (route.includes('initialize') || route.includes('deinitialize') || route.includes('init-progress')){
        result = SourceTypes.DOMAIN;
      } else {
        result = SourceTypes.SIM;
      }
    } else if (route.includes('.infrastructure')){ result = SourceTypes.INFRASTRUCTURE; } else if (route.includes('.image')){ result = SourceTypes.IMAGE; } else { result = SourceTypes.UNK; }
    return result;
  }
}

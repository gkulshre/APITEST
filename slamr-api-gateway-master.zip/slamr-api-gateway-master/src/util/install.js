/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import Utils from './utils';
import logger from './logger';

export default class Install {

  static verifyInstallation() {
    Install.verifyPaths();
  }

  static verifyPaths() {
    var paths = {};
    paths['PATHS_IMAGE_MANAGER_IMPORT'] = process.env.PATHS_IMAGE_MANAGER_IMPORT;
    paths['PATHS_IMAGE_MANAGER_EXPORT'] = process.env.PATHS_IMAGE_MANAGER_EXPORT;
    paths['PATHS_COMPONENT_LIBRARY'] = process.env.PATHS_COMPONENT_LIBRARY;

    Object.keys(paths).forEach(function(key) {
      let path = paths[key];
      logger.info(`Verifying ${path}`);
      if (!Utils.pathExists(path)) {
        Utils.createPath(path);
      }
    });
  }
}

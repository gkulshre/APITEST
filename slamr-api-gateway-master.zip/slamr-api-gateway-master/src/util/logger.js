/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import winston from 'winston';
import path from 'path';
import Utils from './utils';
import 'winston-daily-rotate-file';
require('dotenv').config({ path: path.join(process.cwd(), '/config/.env.' + process.env.NODE_ENV)});

const loggingPath = path.resolve(process.env.SERVER_LOGPATH);

Utils.createPath(loggingPath);

/* Really annoying change to Winston.  Does JSON Timestamp by default
   Had to custom format the message
 */
const logfmt = winston.format.printf((info) => {
  return `${info.timestamp} ${info.level}: ${info.message}`;
});

/* Create the logger and apply formatting */
const logger = winston.createLogger({
  level: process.env.SERVER_LOGGING_LEVEL,
  format: winston.format.combine(
    winston.format.timestamp({
      format: 'YYYY-MM-DD-HH:mm:ss',
    }),
    logfmt
  ),
  transports: [
    new (winston.transports.DailyRotateFile)({
      filename: path.join(loggingPath, process.env.SERVER_LOGFILE),
      datePattern: 'YYYY-MM-DD',
      zippedArchive: true,
      maxSize: '20m',
      maxFiles: '5d',
    }),
  ],
});

/* Add the Unhandled Exception Handling */
logger.exceptions.handle(
  new winston.transports.File({ filename: path.join(loggingPath, 'uh.log')})
);

/* Lets log to console in dev environment shall we */
if (process.env.NODE_ENV === 'development') {
  logger.add(new winston.transports.Console({
    format: winston.format.simple(),
  }));
}

export default logger;

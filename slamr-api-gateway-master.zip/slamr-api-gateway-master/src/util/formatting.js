/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

export default class Fromatting {
  static formatError(code, type, message) {
    let result = {};

    result.msg = message;
    result.code = code;
    result.type = type;

    return result;
  }
}

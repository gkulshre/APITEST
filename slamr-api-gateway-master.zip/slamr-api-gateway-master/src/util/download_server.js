/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

const server = require('node-http-server');
import logger from './logger';

export default function startServer(){
  // Using the near zero configuration node-http-server
  const serverConfig = new server.Config;
  serverConfig.errors['404'];
  serverConfig.port = process.env.DOWNLOAD_SERVER_PORT;
  serverConfig.root = process.env.DOWNLOAD_SERVER_BASE_PATH;
  serverConfig.contentType.gz = 'application/tar+gzip';
  server.deploy(serverConfig, serverReady);
}

function serverReady(server){
  logger.info(`Download server on port ${server.config.port} is now up`);
}


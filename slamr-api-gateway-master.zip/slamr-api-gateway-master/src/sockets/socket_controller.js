/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import SocketIO from 'socket.io';
import ss from 'socket.io-stream';
import logger from '../util/logger';
import ioJWTValidation from '../middlewares/io_jwt_validation';
import fs from 'fs';

export default class SocketController {
  constructor() {
    try {
      this.io_prime = new SocketIO(process.env.SOCKET_SERVER_PORT);
      // this.io_prime.origins('*:*');

      this.LogRoom = 'e95e4974-656b-4348-8b1e-705071385aa3';
      this.AlertRoom = '89183ff9-19a7-412d-b858-e1f2e20ecab1';
      this.MonitorRoom = 'b8824fea-60c1-4836-852e-7f54a32763a0';
      this.ErrorRoom = '29d82f2d-b9b6-4587-91a7-1adca76f77da';
      this.CIFRoom = '86b15bb7-f91a-49bb-86a0-1d91f3dbd53a';
      this.InfrastructureRoom = '2ae2a4e8-ad3e-4eb2-b43a-bf5a42b14383';
      this.ProjectRoom = '9ca04529-3eec-4dd2-bf1d-60c6ecb9c7ed';
      this.ImageRoom = '75c04038-5d6a-4755-a77a-c1fd570b7360';
    } catch (err) {
      logger.error(err.message);
    }
  }

  makeUploadFileDirectory(path, permissions) {
    try {
      if (!fs.existsSync(path)) {
        logger.info(`Upload File Path does not exist: ${path} ... creating now`);
        fs.mkdirSync(path, {mode: permissions, recursive: true});
      }
      return fs.existsSync(path);
    } catch (error) {
      logger.error(`Upload file: ERROR creating dir: ${error.message}`);
    }
  }

  handleUploadFileConnection(stream, data, success, pathConfig, permissions, shouldNestFileInFolderById) {
    let path = shouldNestFileInFolderById ? `${pathConfig}${data.id}/` : `${pathConfig}`;
    logger.info(`: name: ${data.name} id: ${data.id} size: ${data.size} path:${pathConfig}`);
    try {
      if (this.makeUploadFileDirectory(path, permissions)) {
        logger.info(`Upload file: Path created: ${path}`);
        const filePath = path + data.name;
        logger.info(`Upload file: Writing file: ${filePath}`);
        stream.pipe(fs.createWriteStream(filePath, { mode: permissions }));

        stream.on('end', () => {
          if (fs.existsSync(filePath)) {
            logger.info(`Upload file: File written: ${filePath}`);
            success && success(data);
          } else {
            throw new Error(`Path not created?!?!?!? ${filePath}`);
          }
        });

        stream.on('error', err => {
          logger.error(`Upload file: ERROR WITH STREAM: ${err.message}`);
        });
      } else {
        throw new Error(`Path not created?!?!?!? ${path}`);
      }
    } catch (error) {
      logger.error(`Upload file: ERROR: ${error.message}`);
    }
  }

  handleConnections() {
    this.io_prime.use(ioJWTValidation);

    this.io_prime.on('connection', socket => {
      logger.debug(`${socket._sub} Connected...`);

      socket.on('disconnect', () => {
        logger.debug(`${socket._sub} Disconnected...`);
      });

      logger.debug('init upload file handlers');
      const permissions = '0755'; // drwxr-xr-x Files may be executable

      ss(socket).on('import_image', (stream, data, success) => {
        this.handleUploadFileConnection(stream, data, success, process.env.PATHS_IMAGE_MANAGER_IMPORT, permissions, false);
      });

      ss(socket).on('import_component_file', (stream, data, success) => {
        this.handleUploadFileConnection(stream, data, success, process.env.PATHS_COMPONENT_LIBRARY, permissions, true);
      });

      ss(socket).on('download_build_file', (stream, data) => {
        const readStream = fs.createReadStream(data);

        readStream.on('open', () => {
          // This just pipes the read stream to the response object (which goes to the client)
          readStream.pipe(stream);
        });
      });

      if (security.matrix.ready) {
        this.joinRooms(socket);
      } else {
        logger.info(`Security not ready, disconnection ${socket._sub}`);
        socket.disconnect();
      }
    });
  }

  joinRooms(socket) {
    try {
      this.joinRoom(socket, socket._sub); // This room is the unique user (sub on token) for directed comms
      logger.info(`Private room created for ${socket._sub}`);

      if (socket._cysys_admin) {
        // If Admin, join all domains and management/monitoring
        logger.info(`${socket._sub} connecting to socket as super-admin`);
        security.matrix.domains.forEach(d => {
          this.joinRoom(socket, d);
        });
        this.joinRoom(socket, this.LogRoom);
        this.joinRoom(socket, this.AlertRoom);
        this.joinRoom(socket, this.MonitorRoom);
        this.joinRoom(socket, this.ErrorRoom);
        this.joinRoom(socket, this.CIFRoom);
        this.joinRoom(socket, this.InfrastructureRoom);
        this.joinRoom(socket, this.ProjectRoom);
        this.joinRoom(socket, this.ImageRoom);
      } else {
        // Check to see if the user has any group membership with domain read permissions in any domain and add domain if true
        security.matrix.domains.domainReads.forEach(dr => {
          if (dr.reads.some(r => socket.cysys_roles.includes(r))) {
            this.joinRoom(socket, dr.domain);
          }
          this.joinRoom(socket, this.ErrorRoom);
        });
      }

      this.sendUserMessage(socket._sub, 'Connected to all rooms');
    } catch (err) {
      logger.error(err);
    }
  }

  joinRoom(socket, room) {
    socket.join(room);
    logger.debug(`${socket._sub} joined room ${room}`);
  }

  sendUserMessage(user, msg) {
    logger.debug(`Sending user socket message for user ${user}`);
    this.io_prime.to(user).emit('private', msg);
  }

  sendDeviceMessage(domain, msg) {
    logger.debug(`Sending device socket message for domain ${domain}`);
    this.io_prime.to(domain).emit('device', msg);
  }

  sendCIFMessage(domain, msg) {
    logger.debug(`Sending CIF socket message for domain ${domain}`);
    this.io_prime.to(domain).emit('cif', msg);
  }

  sendTrafficMessage(domain, msg) {
    logger.debug(`Sending traffic socket message for domain ${domain}`);
    this.io_prime.to(domain).emit('traffic', msg);
  }

  sendAttackMessage(domain, msg) {
    logger.debug(`Sending attack socket message for domain ${domain}`);
    this.io_prime.to(domain).emit('attack', msg);
  }

  sendNetworkMessage(domain, msg) {
    logger.debug(`Sending network socket message for domain ${domain}`);
    this.io_prime.to(domain).emit('network', msg);
  }

  sendDomainMessage(domain, msg) {
    logger.debug(`Sending domain socket message for domain ${domain}`);
    this.io_prime.to(domain).emit('domain', msg);
  }

  sendEventMessage(domain, msg) {
    logger.debug(`Sending event socket message for domain ${domain}`);
    this.io_prime.to(domain).emit('event', msg);
  }

  sendDomainLogMessage(domain, msg) {
    logger.debug(`Sending log socket message for domain ${domain}`);
    this.io_prime.to(domain).emit('log', msg);
  }

  sendDomainAlertMessage(domain, msg) {
    logger.debug(`Sending alert socket message for domain ${domain}`);
    this.io_prime.to(domain).emit('alert', msg);
  }

  sendDomainErrorMessage(domain, msg) {
    logger.debug(`Sending error socket message for domain ${domain}`);
    this.io_prime.to(domain).emit('error', msg);
  }

  sendDomainExport(domain, filePath) {
    logger.debug(`Exporting for domain ${domain}`);
    fs.readFile(filePath, (err, buff) => {
      if (err) {
        logger.error('Error Reading Domain Export File ' + err.message);
      } else {
        this.io_prime.to(domain).emit('export', buff);
      }
    });
  }

  sendErrorMessage(msg) {
    logger.debug('Sending global error message');
    this.io_prime.to(this.ErrorRoom).emit('global_error', msg);
  }

  sendGlobalCIFMessage(msg) {
    logger.debug('Sending global cif message');
    this.io_prime.to(this.CIFRoom).emit('global_cif', msg);
  }

  sendLogMessage(msg) {
    this.io_prime.to(this.LogRoom).emit('global_log', msg);
  }

  sendAlertMessage(msg) {
    logger.debug('Sending alert socket message' + msg);
    this.io_prime.to(this.AlertRoom).emit('global_alert', msg);
  }

  sendMonitorMessage(msg) {
    logger.debug('Sending monitor socket message');
    this.io_prime.to(this.MonitorRoom).emit('global_monitor', msg);
  }

  sendInfrastructureMessage(msg) {
    logger.debug('Sending infrastructure socket message');
    this.io_prime.to(this.InfrastructureRoom).emit('infrastructure', msg);
  }

  sendImageMessage(msg) {
    logger.debug('Sending image socket message');
    this.io_prime.to(this.ImageRoom).emit('image', msg);
  }

  sendGlobalProjectMessage(msg) {
    logger.debug('Sending global project message');
    this.io_prime.to(this.ProjectRoom).emit('global_project', msg);
  }
}

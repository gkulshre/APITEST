/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import jwt from 'jsonwebtoken';
import logger from '../util/logger';

const ioJWTValidation = (socket, next) => {
  if (process.env.SERVER_USE_AUTHENTICATION){
    let token = socket.handshake.query.token;

    if (typeof token === 'undefined') {
      return next('unauthorized');
    }

    try {
      jwt.verify(token, process.env.JWT_SECRET, function(err, decoded) {
        if (err){
          logger.error(`Socket Authentication Error: ${err}`);
          return next(new Error(err));
        } else {
          logger.debug(`Valid token for ${decoded.sub}`);
          socket._cysys_roles = decoded.cysys_roles;
          socket._cysys_admin = decoded.cysys_admin;
          socket._sub = decoded.sub;
          return next();
        }
      });
    } catch (error) {
      logger.error(`Socket Authentication Error: ${error.message}`);
      return next(new Error(`Server error:  ${error.message}`));
    }
  } else {
    socket._sub = 'OPEN';
    return next();
  }
};

module.exports = ioJWTValidation;

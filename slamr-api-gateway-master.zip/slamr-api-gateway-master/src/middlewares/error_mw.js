/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import logger from '../util/logger';
import Formatting from '../util/formatting';

const formatMeta = (req, error) => {
  let meta = {};

  meta.ip = req.ip;
  meta.url = req.originalUrl;
  meta.method = req.method;
  if (req.params) { (meta.params = req.params); }
  if (error) { (meta.error = error); }

  return meta;
};

const error_mw = (error, req, res, next) => {
  let type = 'Unexpected Error';
  let message = 'Internal Server Error';
  let status = 500;

  if (process.env.NODE_ENV !== 'PROD') {
    if (error.msg) {
      message = error.msg;
    } else {
      message = error;
    }
  }

  if (error.code) {
    if (error.code === 'ETIMEDOUT') {
      message = 'Response timeout';
      type = 'Timeout Error';
      status = 408;
    } else {
      status = error.code;
    }
  } else if (error.bad_input) {
    status = 400;
  }

  logger.error(`REST Error (${req.method}) - ${req.originalUrl} - ${req.ip}`, formatMeta(req, error));
  try {
    if (res.headersSent === false){
      res.status(status).send(Formatting.formatError(status, type, message));
    }
  } catch (err) {
    logger.error(`Unable to send error message:: ${err.message}`);
  }
};

module.exports = error_mw;

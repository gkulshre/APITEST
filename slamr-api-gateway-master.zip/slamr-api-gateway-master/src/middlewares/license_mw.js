/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

const no_license = ['/api/auth', '/api/ping', '/api/core/license-manager'];

const license_mw = (req, res, next) => {

  if (process.env.LICENSE_ENGINEERING != null){
    if (process.env.LICENSE_ENGINEERING === '0fbf5289-8f79-414d-aca3-cd620c06e177'){
      return next();
    } else {
      return res.status(403).json({ message: 'unauthorized configuration' });
    }
  } else {
    // return next();
    if (no_license.includes(req.path)){
      return next();
    } else {
      if ((req.path.includes('core') || req.path.includes('link')) && security.license.products.includes(process.env.LICENSE_TYPES_BASE)){
        return next();
      }
      if ((req.path.includes('/core/lookups') || req.path.includes('designer') || req.path.includes('link')) && security.license.products.includes(process.env.LICENSE_TYPES_PROJECT_DESIGNER)){
        return next();
      }
      if ((req.path.includes('/core/lookups') || req.path.includes('image_designer') || req.path.includes('link')) && security.license.products.includes(process.env.LICENSE_TYPES_IMAGE_DESIGNER)){
        return next();
      }
      return res.status(403).json({ message: 'Not Licensed' });
    }
  }
};

module.exports = license_mw;

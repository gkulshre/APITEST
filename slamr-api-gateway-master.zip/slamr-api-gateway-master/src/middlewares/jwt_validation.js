/**
 * Copyright © 2009-2020 by Metova Federal, LLC.  All rights reserved
 */

import jwt from 'jsonwebtoken';

const no_auth = ['/api/auth', '/api/auth/accounts/reset-password', '/api/ping'];

const jwtValidation = (req, res, next) => {
  if (process.env.SERVER_USE_AUTHENTICATION && !no_auth.includes(req.path)){ // Allow Authentication Attemps without Token
    let token = req.headers['authorization'];

    if (typeof token === 'undefined') {
      return res.status(401).json({ message: 'unauthorized' });
    }

    let bearer = token.split(' ');

    if (bearer[0] === 'Bearer') {
      token = bearer[1];
    }

    try {
      jwt.verify(token, process.env.JWT_SECRET, function(err, decoded) {

        if (err){
          return res.status(401).json({ message: err });
        } else {
          req.cysys_roles = decoded.cysys_roles;
          req.cysys_admin = decoded.cysys_admin;
          req.cysys_super_admin = decoded.cysys_super_admin;
          req.sub = decoded.sub;
          req.token_exp = decoded.exp;
          req.token = token;

          return next();
        }
      });
    } catch (error) {
      return res.status(401).json({ message: error.message });
    }
  } else {
    return next();
  }
};

module.exports = jwtValidation;

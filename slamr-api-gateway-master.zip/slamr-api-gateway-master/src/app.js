/**
 * Copyright © 2009-2020 by Metova Federal, LLC. All rights reserved.
 * SLAM-R Copyright © 2009-2020 by Metova Federal, LLC. All rights reserved.
 * SLAM-R v3. Copyright © 2020 by By Light Professional IT Services.  All rights reserved.
 * Patent Issued, Metova Federal, LLC; Patent No.: US8,532,970 B2, September 10, 2013 – Systems and Methods for Network Monitoring and Analysis of a Simulated Network.
 * Patent Issued, Metova Federal, LLC; Patent No.: US8,751,629, June 10, 2014 – Systems and Methods for Automated Building of a Simulated Network Environment.
 * Patent Issued, Metova Federal, LLC; Patent No.: US9,246,768, January 26, 2016 – Systems and Methods for a Simulated Network Attack Generator.
 * Patent Issued, Metova Federal, LLC; Patent No.: US10,313,203 B2, June 4, 2019 – Divisional of Systems and Methods for Network Monitoring and Analysis of a Simulated Network (Traffic Generation).
 * CYNTRS®, HOTSIM®, RGI®, VCCE®, CENTS®, SLAM-R®, and CyberCENTS® are registered trademarks of Metova Federal, LLC through the USPTO.
 */

import express from 'express';
import morgan from 'morgan';
import bodyParser from 'body-parser';
import cors from 'cors';
import { apiRoutes } from './routes/routes';
import jwtValidate from './middlewares/jwt_validation';
import license_mw from './middlewares/license_mw';
import rmqController from './amqp/rmq_controller';
import logger from './util/logger';
import SocketController from './sockets/socket_controller';
import MatrixController from './security/matrix_controller';
import errorMw from './middlewares/error_mw';
import LicenseController from './security/license_controller';
const listEndpoints = require('express-list-endpoints');


const app = express();

app.use(cors());
app.use(morgan('dev'));

app.use(bodyParser.json({limit: '100mb'}));
app.use(bodyParser.urlencoded({ limit: '100mb' }));

/*
    Set up Global Singletons here
 */
global.rmqC = rmqController(cbRmq);
global.orchSyncQueue = new Map();
global.asyncQueue = new Map();
global.syncQueue = new Map();
global.io = new SocketController();
global.security = {};

//  -------------------------------

// Considering Promise Chain in future

/* eslint-disable no-unused-vars */
function cbRmqFail() {
  /* eslint-enable no-unused-vars */
  // TODO:  Handle full RMQ failure (kill app)
  logger.error('RMQ Connectivity Failed!');
}

function cbStart() {
  io.handleConnections();
  app.use('/api', apiRoutes());
  app.use(errorMw);
  logger.info('API Gateway Started!');
  global.endpoints = listEndpoints(app);
}

function cbRmq() {
  try {
    app.all('/*', jwtValidate);
    app.all('/*', license_mw);
    security.license.start();
    security.matrix.start(cbStart);
  } catch (err) {
    logger.error(`API Gateway failed to start: ${err.message}`);
    cbStart();
  }
}
logger.debug('Starting...');
security.matrix = new MatrixController();
security.license = new LicenseController();
rmqC.blockingStart(cbRmq);

export default app;
